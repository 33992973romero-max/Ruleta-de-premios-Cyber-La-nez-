import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// High payload limit for image uploads
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Ensure data and upload directories exist
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const UPLOADS_DIR = path.join(__dirname, 'public', 'uploads');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Serve uploaded assets
app.use('/uploads', express.static(UPLOADS_DIR));

// Helper to read and write database
function getDb() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Error reading db.json:', err);
  }
  return { prizes: [], history: [], settings: {} };
}

function saveDb(data: any) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing db.json:', err);
  }
}

// ================= API ENDPOINTS =================

// 1. Get all game data (prizes, history, settings)
app.get('/api/data', (_req, res) => {
  const db = getDb();
  res.json(db);
});

// 2. Update prizes
app.post('/api/prizes', (req, res) => {
  const { prizes } = req.body;
  if (!Array.isArray(prizes)) {
    return res.status(400).json({ error: 'Formato de premios inválido' });
  }
  const db = getDb();
  db.prizes = prizes;
  saveDb(db);
  res.json({ success: true, prizes });
});

// 3. Update settings
app.post('/api/settings', (req, res) => {
  const { settings } = req.body;
  if (!settings) {
    return res.status(400).json({ error: 'Configuración requerida' });
  }
  const db = getDb();
  db.settings = { ...db.settings, ...settings };
  saveDb(db);
  res.json({ success: true, settings: db.settings });
});

// 4. Record new spin
app.post('/api/spin', (req, res) => {
  const { record } = req.body;
  if (!record || !record.phoneNumber) {
    return res.status(400).json({ error: 'Registro de giro inválido' });
  }
  const db = getDb();
  const cleanPhone = String(record.phoneNumber).replace(/[^0-9]/g, '');

  // Double check on server
  const alreadyPlayed = (db.history || []).some(
    (h: any) => String(h.phoneNumber).replace(/[^0-9]/g, '') === cleanPhone
  );

  if (alreadyPlayed) {
    return res.status(409).json({ error: 'Este número de teléfono ya ha participado' });
  }

  db.history = db.history || [];
  db.history.unshift(record);
  saveDb(db);
  res.json({ success: true, record });
});

// 5. Delete specific history record
app.delete('/api/history/:id', (req, res) => {
  const { id } = req.params;
  const db = getDb();
  db.history = (db.history || []).filter((h: any) => h.id !== id);
  saveDb(db);
  res.json({ success: true, history: db.history });
});

// 6. Toggle claimed state
app.patch('/api/history/:id/toggle', (req, res) => {
  const { id } = req.params;
  const db = getDb();
  db.history = (db.history || []).map((h: any) =>
    h.id === id ? { ...h, claimed: !h.claimed } : h
  );
  saveDb(db);
  res.json({ success: true, history: db.history });
});

// 7. Clear all history
app.post('/api/history/clear', (_req, res) => {
  const db = getDb();
  db.history = [];
  saveDb(db);
  res.json({ success: true, history: [] });
});

// 8. Upload image file and save to public/uploads/ so everyone can view it!
app.post('/api/upload', (req, res) => {
  try {
    const { imageBase64, filenamePrefix } = req.body;
    if (!imageBase64 || typeof imageBase64 !== 'string') {
      return res.status(400).json({ error: 'Imagen en base64 requerida' });
    }

    // Extract format
    const matches = imageBase64.match(/^data:image\/([A-Za-z0-9-+]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      // If it's already an external URL, just return it
      if (imageBase64.startsWith('http://') || imageBase64.startsWith('https://')) {
        return res.json({ url: imageBase64 });
      }
      return res.status(400).json({ error: 'Formato de imagen inválido' });
    }

    const extension = matches[1] === 'jpeg' ? 'jpg' : matches[1];
    const base64Data = matches[2];
    const filename = `${filenamePrefix || 'img'}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}.${extension}`;
    const filePath = path.join(UPLOADS_DIR, filename);

    fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));
    const publicUrl = `/uploads/${filename}`;

    res.json({ success: true, url: publicUrl });
  } catch (err: any) {
    console.error('Error saving image upload:', err);
    res.status(500).json({ error: 'Error al guardar la imagen en el servidor' });
  }
});

// ================= DEV VS PROD SERVER =================
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
