/**
 * Web Audio API Sound Synthesizer for game effects
 * Generates all audio procedurally without external audio file dependencies.
 */

class SoundController {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  constructor() {
    // sound is enabled by default
    const stored = localStorage.getItem('sound_enabled');
    if (stored !== null) {
      this.enabled = stored === 'true';
    }
  }

  public toggleSound(): boolean {
    this.enabled = !this.enabled;
    localStorage.setItem('sound_enabled', String(this.enabled));
    return this.enabled;
  }

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public playTick(pitchMultiplier = 1.0) {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(450 * pitchMultiplier, t);
      osc.frequency.exponentialRampToValueAtTime(120 * pitchMultiplier, t + 0.04);

      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.05);
    } catch {
      // AudioContext safe fail
    }
  }

  public playClick() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(700, t);
      osc.frequency.exponentialRampToValueAtTime(300, t + 0.06);

      gain.gain.setValueAtTime(0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.06);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.07);
    } catch {}
  }

  public playWhoosh() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, t);
      osc.frequency.exponentialRampToValueAtTime(600, t + 0.3);

      gain.gain.setValueAtTime(0.01, t);
      gain.gain.linearRampToValueAtTime(0.15, t + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.35);
    } catch {}
  }

  public playChestThump() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(130, t);
      osc.frequency.exponentialRampToValueAtTime(35, t + 0.25);

      gain.gain.setValueAtTime(0.5, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.3);
    } catch {}
  }

  public playChestUnlock() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      [880, 1320, 1760].forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t + idx * 0.06);

        gain.gain.setValueAtTime(0.2, t + idx * 0.06);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.06 + 0.18);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(t + idx * 0.06);
        osc.stop(t + idx * 0.06 + 0.2);
      });
    } catch {}
  }

  public playLegendaryFanfare() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      // Epic uplifting Clash Royale style legendary fanfare chords:
      // Note frequencies (C5, E5, G5, B5, C6)
      const notes = [
        { f: 523.25, time: 0.0, dur: 0.18 }, // C5
        { f: 659.25, time: 0.14, dur: 0.18 }, // E5
        { f: 783.99, time: 0.28, dur: 0.22 }, // G5
        { f: 987.77, time: 0.44, dur: 0.25 }, // B5
        { f: 1046.50, time: 0.65, dur: 0.9 }, // High C6 (long triumphant finish)
      ];

      notes.forEach((n) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(n.f, t + n.time);

        // Warm harmonic sub-oscillator
        const sub = this.ctx!.createOscillator();
        sub.type = 'sine';
        sub.frequency.setValueAtTime(n.f / 2, t + n.time);

        gain.gain.setValueAtTime(0.25, t + n.time);
        gain.gain.exponentialRampToValueAtTime(0.001, t + n.time + n.dur);

        osc.connect(gain);
        sub.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(t + n.time);
        sub.start(t + n.time);
        osc.stop(t + n.time + n.dur);
        sub.stop(t + n.time + n.dur);
      });

      // Shimmering sparkle arpeggio on top
      const sparkleTimes = [0.7, 0.8, 0.9, 1.0, 1.1, 1.25];
      const sparkleFreqs = [1567.98, 1760.00, 2093.00, 2637.02, 3135.96, 4186.01];

      sparkleTimes.forEach((st, i) => {
        const sOsc = this.ctx!.createOscillator();
        const sGain = this.ctx!.createGain();

        sOsc.type = 'sine';
        sOsc.frequency.setValueAtTime(sparkleFreqs[i % sparkleFreqs.length], t + st);

        sGain.gain.setValueAtTime(0.12, t + st);
        sGain.gain.exponentialRampToValueAtTime(0.001, t + st + 0.18);

        sOsc.connect(sGain);
        sGain.connect(this.ctx!.destination);

        sOsc.start(t + st);
        sOsc.stop(t + st + 0.2);
      });
    } catch {}
  }

  public playFailSound() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const notes = [
        { f: 380, time: 0.0, dur: 0.22 },
        { f: 340, time: 0.22, dur: 0.22 },
        { f: 290, time: 0.44, dur: 0.35 },
        { f: 240, time: 0.75, dur: 0.5 },
      ];

      notes.forEach((n) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(n.f, t + n.time);

        // Lowpass filter for muffled cartoon feel
        const filter = this.ctx!.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(600, t + n.time);

        gain.gain.setValueAtTime(0.18, t + n.time);
        gain.gain.exponentialRampToValueAtTime(0.001, t + n.time + n.dur);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(t + n.time);
        osc.stop(t + n.time + n.dur);
      });
    } catch {}
  }

  public playChestRumble() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(60, t);
      osc.frequency.linearRampToValueAtTime(140, t + 0.35);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(180, t);
      filter.frequency.linearRampToValueAtTime(320, t + 0.35);

      gain.gain.setValueAtTime(0.05, t);
      gain.gain.linearRampToValueAtTime(0.3, t + 0.2);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.35);
    } catch {}
  }

  public playChestExplosion() {
    if (!this.enabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      // Sub bass boom
      const sub = this.ctx.createOscillator();
      const subGain = this.ctx.createGain();
      sub.type = 'sine';
      sub.frequency.setValueAtTime(180, t);
      sub.frequency.exponentialRampToValueAtTime(30, t + 0.45);

      subGain.gain.setValueAtTime(0.6, t);
      subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

      sub.connect(subGain);
      subGain.connect(this.ctx.destination);

      sub.start(t);
      sub.stop(t + 0.45);

      // Shimmering chimes cascade
      [1200, 1600, 2100, 2800, 3500].forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t + idx * 0.04);
        gain.gain.setValueAtTime(0.18, t + idx * 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.04 + 0.25);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(t + idx * 0.04);
        osc.stop(t + idx * 0.04 + 0.3);
      });
    } catch {}
  }
}

export const sound = new SoundController();
