import { AdminSettings, Prize, SpinRecord, ThemeConfig } from '../types/game';

const STORAGE_KEYS = {
  PRIZES: 'roulette_prizes_v1',
  HISTORY: 'roulette_history_v1',
  SETTINGS: 'roulette_settings_v1',
};

export const DEFAULT_PRIZES: Prize[] = [
  {
    id: 'prize-1',
    name: 'PlayStation 5',
    description: 'Consola PS5 Slim Edition Digital con DualSense',
    isPrize: true,
    chestType: 'legendary',
    color: '#3b82f6',
    textColor: '#ffffff',
    weight: 2,
    imageUrl: 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?auto=format&fit=crop&w=500&q=80',
    couponPrefix: 'PS5',
  },
  {
    id: 'prize-2',
    name: 'iPhone 16 Pro',
    description: 'Smartphone de última generación 128GB',
    isPrize: true,
    chestType: 'legendary',
    color: '#8b5cf6',
    textColor: '#ffffff',
    weight: 1,
    imageUrl: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=500&q=80',
    couponPrefix: 'IPHONE',
  },
  {
    id: 'prize-3',
    name: 'Tarjeta Regalo $50',
    description: 'Válido para compras en la tienda o saldo digital',
    isPrize: true,
    chestType: 'legendary',
    color: '#eab308',
    textColor: '#0f172a',
    weight: 6,
    imageUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=500&q=80',
    couponPrefix: 'GIFT50',
  },
  {
    id: 'prize-4',
    name: 'Audífonos Pro',
    description: 'Audífonos inalámbricos con cancelación de ruido',
    isPrize: true,
    chestType: 'legendary',
    color: '#ec4899',
    textColor: '#ffffff',
    weight: 8,
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=500&q=80',
    couponPrefix: 'SOUND',
  },
  {
    id: 'prize-5',
    name: 'Combo Especial',
    description: 'Cena o merienda premium para 2 personas',
    isPrize: true,
    chestType: 'legendary',
    color: '#f97316',
    textColor: '#ffffff',
    weight: 10,
    imageUrl: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=500&q=80',
    couponPrefix: 'COMBO',
  },
  {
    id: 'prize-6',
    name: '20% Descuento',
    description: 'Cupón aplicable en cualquier compra hoy',
    isPrize: true,
    chestType: 'legendary',
    color: '#10b981',
    textColor: '#ffffff',
    weight: 15,
    imageUrl: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=500&q=80',
    couponPrefix: 'DESC20',
  },
  {
    id: 'prize-7',
    name: '¡Sigue Intentando!',
    description: 'No te desanimes, la próxima vez la suerte estará de tu lado.',
    isPrize: false,
    chestType: 'normal',
    color: '#64748b',
    textColor: '#ffffff',
    weight: 35,
    imageUrl: 'https://images.unsplash.com/photo-1579208575657-c595a053b977?auto=format&fit=crop&w=500&q=80',
  },
  {
    id: 'prize-8',
    name: 'Suerte La Próxima',
    description: 'Casi lo logras. ¡Gracias por participar!',
    isPrize: false,
    chestType: 'normal',
    color: '#475569',
    textColor: '#ffffff',
    weight: 35,
    imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80',
  },
];

export const DEFAULT_THEME: ThemeConfig = {
  fontFamily: "'Luckiest Guy', cursive, sans-serif",
  fontName: 'Clash Royale Arcade (Luckiest Guy)',
  titleColor: '#ffffff',
  subtitleColor: '#cbd5e1',
  accentColor: '#fbbf24',
  mainTitle: '¡GIRA Y GANA!',
  subtitle: 'Abre el cofre legendario estilo Clash Royale y descubre tu premio.',
  bannerText: '',
  spinButtonText: '¡GIRAR RULETA AHORA!',
};

export const DEFAULT_SETTINGS: AdminSettings = {
  adminPin: '108110',
  storeName: 'Ruleta de Premios',
  claimInstructions: 'Presenta tu pantalla con tu premio y número en caja o envía una captura a nuestro WhatsApp oficial para reclamarlo.',
  headerLogoUrl: '',
  wheelCenterLogoUrl: '',
  noPrizeConfig: {
    title: '¡Oh no! Cofre Vacío',
    message: 'Esta vez la suerte no estuvo contigo, pero gracias de corazón por participar con nosotros.',
    imageUrl: 'https://images.unsplash.com/photo-1579208575657-c595a053b977?auto=format&fit=crop&w=500&q=80',
  },
  themeConfig: DEFAULT_THEME,
};

export const storage = {
  /**
   * Fetch all synchronized data from the server so anyone with the shared link
   * sees the exact uploaded images, prizes, and settings!
   */
  async fetchServerData(): Promise<{
    prizes?: Prize[];
    history?: SpinRecord[];
    settings?: AdminSettings;
  } | null> {
    try {
      const res = await fetch('/api/data');
      if (res.ok) {
        const data = await res.json();
        if (data.prizes && Array.isArray(data.prizes) && data.prizes.length >= 2) {
          localStorage.setItem(STORAGE_KEYS.PRIZES, JSON.stringify(data.prizes));
        }
        if (data.history && Array.isArray(data.history)) {
          localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(data.history));
        }
        if (data.settings && typeof data.settings === 'object') {
          const merged = { ...DEFAULT_SETTINGS, ...data.settings };
          localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(merged));
        }
        return data;
      }
    } catch {
      // Offline or network fallback to localStorage
    }
    return null;
  },

  getPrizes(): Prize[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PRIZES);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length >= 2) return parsed;
      }
    } catch {}
    this.savePrizes(DEFAULT_PRIZES);
    return DEFAULT_PRIZES;
  },

  savePrizes(prizes: Prize[]) {
    localStorage.setItem(STORAGE_KEYS.PRIZES, JSON.stringify(prizes));
    // Sync to backend so shared link viewers get updated prizes
    fetch('/api/prizes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prizes }),
    }).catch(() => {});
  },

  getHistory(): SpinRecord[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.HISTORY);
      if (data) {
        return JSON.parse(data);
      }
    } catch {}
    return [];
  },

  saveHistory(history: SpinRecord[]) {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));
  },

  getSettings(): AdminSettings {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (data) {
        const parsed = JSON.parse(data);
        if (parsed.adminPin === '7777' || parsed.adminPin === '1081') parsed.adminPin = '108110';
        if (parsed.storeName === 'Ruleta Royale Premios') parsed.storeName = 'Ruleta de Premios';
        if (parsed.themeConfig?.bannerText === '1 Giro Gratis por Teléfono') parsed.themeConfig.bannerText = '';

        return {
          ...DEFAULT_SETTINGS,
          ...parsed,
          themeConfig: {
            ...DEFAULT_THEME,
            ...(parsed.themeConfig || {}),
          },
          noPrizeConfig: {
            ...DEFAULT_SETTINGS.noPrizeConfig,
            ...(parsed.noPrizeConfig || {}),
          },
        };
      }
    } catch {}
    this.saveSettings(DEFAULT_SETTINGS);
    return DEFAULT_SETTINGS;
  },

  saveSettings(settings: AdminSettings) {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    // Sync to backend so shared link viewers get updated settings & logo
    fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ settings }),
    }).catch(() => {});
  },

  checkPhonePlayed(rawPhone: string): SpinRecord | null {
    const cleanPhone = normalizePhone(rawPhone);
    if (!cleanPhone) return null;
    const history = this.getHistory();
    return history.find((record) => normalizePhone(record.phoneNumber) === cleanPhone) || null;
  },

  recordSpin(record: SpinRecord) {
    const history = this.getHistory();
    history.unshift(record);
    this.saveHistory(history);
    // Sync to backend
    fetch('/api/spin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ record }),
    }).catch(() => {});
  },

  deleteRecord(id: string) {
    const history = this.getHistory().filter((r) => r.id !== id);
    this.saveHistory(history);
    fetch(`/api/history/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
  },

  toggleClaimed(id: string) {
    const history = this.getHistory().map((r) => {
      if (r.id === id) {
        return { ...r, claimed: !r.claimed };
      }
      return r;
    });
    this.saveHistory(history);
    fetch(`/api/history/${encodeURIComponent(id)}/toggle`, { method: 'PATCH' }).catch(() => {});
  },

  clearAllHistory() {
    this.saveHistory([]);
    fetch('/api/history/clear', { method: 'POST' }).catch(() => {});
  },

  /**
   * Upload an image to the server so it is hosted permanently as a static file
   * accessible across all devices and shared links!
   */
  async uploadImage(imageBase64: string, prefix = 'img'): Promise<string> {
    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64, filenamePrefix: prefix }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.url) return data.url;
      }
    } catch (err) {
      console.warn('Fallback: saving image base64 locally', err);
    }
    return imageBase64; // fallback to base64 if server upload fails
  },
};

export function normalizePhone(phone: string): string {
  return phone.replace(/[^0-9]/g, '');
}

export function generateClaimCode(prefix = 'ROYALE'): string {
  const randomPart = Math.floor(1000 + Math.random() * 9000);
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const charPart = chars[Math.floor(Math.random() * chars.length)] + chars[Math.floor(Math.random() * chars.length)];
  return `${prefix}-${charPart}${randomPart}`;
}
