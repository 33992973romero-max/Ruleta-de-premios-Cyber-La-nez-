export type ChestType = 'legendary' | 'normal';

export interface Prize {
  id: string;
  name: string;
  description?: string;
  isPrize: boolean; // true = wins real prize (Legendary chest), false = no prize (Normal chest)
  color: string;
  textColor: string;
  iconName?: string;
  imageUrl: string;
  weight: number; // relative weight for probability calculation
  chestType: ChestType;
  couponPrefix?: string;
}

export interface SpinRecord {
  id: string;
  phoneNumber: string;
  timestamp: number;
  prizeId: string;
  prizeName: string;
  isPrize: boolean;
  chestType: ChestType;
  claimCode: string;
  claimed: boolean;
  notes?: string;
}

export interface NoPrizeConfig {
  imageUrl: string;
  title: string;
  message: string;
}

export interface ThemeConfig {
  fontFamily: string; // e.g., "'Luckiest Guy', cursive", "'Bungee', cursive", "'Cinzel', serif", etc.
  fontName: string; // friendly display name
  titleColor: string; // Hex for headings
  subtitleColor: string; // Hex for descriptions
  accentColor: string; // Hex for highlights and borders
  mainTitle: string; // Customizable main heading, default "¡GIRA Y GANA!"
  subtitle: string; // Customizable subtitle
  bannerText: string; // Banner text (optional)
  spinButtonText: string; // Text for spin button, default "¡GIRAR RULETA AHORA!"
}

export interface AdminSettings {
  adminPin: string;
  storeName: string;
  claimInstructions: string;
  headerLogoUrl?: string; // Optional custom logo image in place of the golden crown
  wheelCenterLogoUrl?: string; // Optional custom logo image in the center of the wheel
  noPrizeConfig: NoPrizeConfig;
  themeConfig: ThemeConfig;
}
