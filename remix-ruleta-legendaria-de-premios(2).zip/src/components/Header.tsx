import React from 'react';
import { Volume2, VolumeX, Shield, Crown, Sparkles } from 'lucide-react';
import { sound } from '../utils/sound';

interface HeaderProps {
  storeName: string;
  headerLogoUrl?: string;
  isSoundEnabled: boolean;
  onToggleSound: () => void;
  onOpenAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  storeName,
  headerLogoUrl,
  isSoundEnabled,
  onToggleSound,
  onOpenAdmin,
}) => {
  return (
    <header className="w-full max-w-md mx-auto pt-3 px-4 pb-1 flex flex-col z-20">
      {/* Top action controls (Sound on Left, Admin on Right) */}
      <div className="w-full flex items-center justify-between mb-1.5">
        {/* Sound toggle button */}
        <button
          onClick={() => {
            sound.playClick();
            onToggleSound();
          }}
          className="h-8 px-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-slate-300 hover:text-white flex items-center gap-1.5 transition active:scale-90 cursor-pointer shadow-sm hover:border-slate-700"
          title={isSoundEnabled ? 'Silenciar sonidos' : 'Activar sonidos'}
        >
          {isSoundEnabled ? (
            <>
              <Volume2 className="w-4 h-4 text-amber-400" />
              <span className="text-[10px] font-bold text-slate-400">SONIDO</span>
            </>
          ) : (
            <>
              <VolumeX className="w-4 h-4 text-slate-500" />
              <span className="text-[10px] font-bold text-slate-500">MUTED</span>
            </>
          )}
        </button>

        {/* Admin button */}
        <button
          onClick={() => {
            sound.playClick();
            onOpenAdmin();
          }}
          className="h-8 px-3 rounded-xl bg-slate-900/90 border border-amber-500/40 text-amber-300 hover:text-amber-200 flex items-center gap-1.5 text-xs font-clash shadow-sm transition active:scale-95 cursor-pointer hover:bg-slate-800/90"
          title="Panel de Administrador"
        >
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span>ADMIN</span>
        </button>
      </div>

      {/* Main Brand Header (Crown side-by-side with Ruleta de premios) */}
      <div className="w-full flex items-center justify-center gap-2.5 sm:gap-3.5 my-1.5 select-none">
        {/* Golden Crown Badge */}
        <div className="relative shrink-0">
          <div className="w-11 h-11 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 p-0.5 shadow-lg shadow-amber-500/30 flex items-center justify-center transform transition-transform hover:scale-105">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center overflow-hidden p-1">
              {headerLogoUrl ? (
                <img
                  src={headerLogoUrl}
                  alt={storeName}
                  className="w-full h-full object-contain"
                />
              ) : (
                <Crown className="w-6 h-6 sm:w-8 sm:h-8 text-amber-400 fill-amber-400 filter drop-shadow-[0_2px_8px_rgba(251,191,36,0.6)] animate-pulse" />
              )}
            </div>
          </div>

          {/* Sparkle emblem decoration */}
          <div className="absolute -top-1 -right-1">
            <Sparkles className="w-4 h-4 text-yellow-300 fill-yellow-300 animate-spin-slow" />
          </div>
        </div>

        {/* Big Name: "Ruleta de Premios" */}
        <h1 className="font-clash text-2xl sm:text-3xl md:text-4xl text-amber-300 text-stroke-gold tracking-wide drop-shadow-xl text-center leading-tight">
          {storeName}
        </h1>
      </div>
    </header>
  );
};
