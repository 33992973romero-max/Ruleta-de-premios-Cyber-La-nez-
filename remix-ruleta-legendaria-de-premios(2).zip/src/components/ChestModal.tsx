import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Share2,
  Gift,
  ArrowRight,
  Flame,
  Crown,
  Coins,
  Gem,
  Zap,
} from 'lucide-react';
import { Prize, SpinRecord, NoPrizeConfig, ThemeConfig } from '../types/game';
import { sound } from '../utils/sound';

interface ChestModalProps {
  prize: Prize;
  spinRecord: SpinRecord;
  noPrizeConfig: NoPrizeConfig;
  storeName: string;
  claimInstructions: string;
  themeConfig?: ThemeConfig;
  onClose: () => void;
}

type ChestPhase = 'falling' | 'ready' | 'opening' | 'revealed';

export const ChestModal: React.FC<ChestModalProps> = ({
  prize,
  spinRecord,
  noPrizeConfig,
  storeName,
  claimInstructions,
  themeConfig,
  onClose,
}) => {
  const isLegendary = prize.chestType === 'legendary' && prize.isPrize;
  const [phase, setPhase] = useState<ChestPhase>('falling');
  const [shaking, setShaking] = useState<boolean>(false);
  const [flash, setFlash] = useState<boolean>(false);
  const [shockwaveActive, setShockwaveActive] = useState<boolean>(false);

  // Initial chest drop sound & landing impact shockwave
  useEffect(() => {
    sound.playChestThump();
    const shockTimer = setTimeout(() => {
      setShockwaveActive(true);
    }, 450);

    const readyTimer = setTimeout(() => {
      setPhase('ready');
      setShockwaveActive(false);
    }, 700);

    return () => {
      clearTimeout(shockTimer);
      clearTimeout(readyTimer);
    };
  }, []);

  // Multi-stage fireworks sequence function for both chest types
  const launchFireworks = (legendary: boolean) => {
    const colors = legendary
      ? ['#ffd700', '#ff007f', '#9b5de5', '#00f5d4', '#fee440', '#ffffff', '#38bdf8']
      : ['#f59e0b', '#fbbf24', '#d97706', '#94a3b8', '#e2e8f0', '#ffffff'];

    try {
      // 1st salvo: immediate explosive core burst
      confetti({
        particleCount: legendary ? 100 : 65,
        spread: 85,
        origin: { y: 0.55 },
        colors,
        startVelocity: 50,
      });

      // 2nd salvo: Left and right crossfire fireworks
      setTimeout(() => {
        confetti({
          particleCount: legendary ? 120 : 75,
          angle: 60,
          spread: 70,
          origin: { x: 0.05, y: 0.65 },
          colors,
        });
        confetti({
          particleCount: legendary ? 120 : 75,
          angle: 120,
          spread: 70,
          origin: { x: 0.95, y: 0.65 },
          colors,
        });
      }, 300);

      // 3rd salvo: High altitude shimmering burst with stars
      setTimeout(() => {
        confetti({
          particleCount: legendary ? 140 : 85,
          spread: 110,
          origin: { x: 0.5, y: 0.3 },
          colors,
          shapes: ['star', 'circle'],
          ticks: 260,
          scalar: 1.25,
        });
      }, 700);

      // 4th salvo: Grande finale
      setTimeout(() => {
        confetti({
          particleCount: legendary ? 110 : 55,
          angle: 90,
          spread: 130,
          origin: { x: 0.5, y: 0.75 },
          colors,
        });
      }, 1100);
    } catch {}
  };

  // When phase becomes revealed, trigger audio, screen flash, and fireworks
  useEffect(() => {
    if (phase === 'revealed') {
      setFlash(true);
      setTimeout(() => setFlash(false), 350);

      if (isLegendary) {
        sound.playLegendaryFanfare();
        launchFireworks(true);
      } else {
        sound.playFailSound();
        launchFireworks(false);
      }
    }
  }, [phase, isLegendary]);

  // Handle tapping on the chest to crack and open it
  const handleChestTap = () => {
    if (phase === 'falling' || phase === 'opening' || phase === 'revealed') return;

    // Exciting tactile shake & rumble
    setShaking(true);
    sound.playChestRumble();
    sound.playTick(1.5);
    setShockwaveActive(true);

    setTimeout(() => {
      setShaking(false);
      setShockwaveActive(false);
    }, 380);

    // Trigger opening sequence
    setPhase('opening');
    sound.playChestUnlock();

    // Trigger explosive chest bursting sound shortly after unlock
    setTimeout(() => {
      sound.playChestExplosion();
    }, 280);

    // Transition to revealed prize view with flash
    setTimeout(() => {
      setPhase('revealed');
    }, 950);
  };

  const handleShareWhatsApp = () => {
    const text = isLegendary
      ? `🎉 ¡Gané "${prize.name}" en la ruleta de ${storeName}! 🏆`
      : `Participé en la ruleta de ${storeName}. ¡Estuvo genial!`;
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const customFont = themeConfig?.fontFamily ? { fontFamily: themeConfig.fontFamily } : {};

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/94 backdrop-blur-md overflow-y-auto animate-in fade-in duration-300">
      {/* Screen White Flash Effect */}
      <div
        className={`fixed inset-0 bg-white pointer-events-none z-60 transition-opacity duration-300 ${
          flash ? 'opacity-90' : 'opacity-0'
        }`}
      />

      {/* Floating magical sparks and ambient energy */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {Array.from({ length: 18 }).map((_, i) => (
          <div
            key={i}
            className={`absolute rounded-full animate-ping ${
              isLegendary ? 'bg-cyan-300 shadow-[0_0_8px_#38bdf8]' : 'bg-amber-400 shadow-[0_0_8px_#f59e0b]'
            }`}
            style={{
              width: `${(i % 3) * 2 + 3}px`,
              height: `${(i % 3) * 2 + 3}px`,
              top: `${12 + (i * 11) % 76}%`,
              left: `${8 + (i * 17) % 84}%`,
              animationDuration: `${1.4 + (i % 4) * 0.4}s`,
              opacity: 0.7,
            }}
          />
        ))}
      </div>

      {/* Background magical radiant rays for Legendary Chest */}
      {isLegendary && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center overflow-hidden">
          <div className="w-[900px] h-[900px] opacity-45 animate-spin-slow bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cyan-400 via-purple-600 to-transparent blur-3xl" />
          <svg
            className="absolute w-[720px] h-[720px] opacity-35 animate-spin-slow text-yellow-300"
            viewBox="0 0 100 100"
            fill="currentColor"
          >
            {Array.from({ length: 24 }).map((_, i) => (
              <polygon
                key={i}
                points="50,50 48.5,0 51.5,0"
                transform={`rotate(${i * 15} 50 50)`}
              />
            ))}
          </svg>
        </div>
      )}

      {/* Background warm rays for Normal Chest */}
      {!isLegendary && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center overflow-hidden">
          <div className="w-[700px] h-[700px] opacity-35 animate-spin-slow bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-500 via-orange-950 to-transparent blur-3xl" />
          <svg
            className="absolute w-[600px] h-[600px] opacity-20 animate-spin-slow text-amber-400"
            viewBox="0 0 100 100"
            fill="currentColor"
          >
            {Array.from({ length: 16 }).map((_, i) => (
              <polygon
                key={i}
                points="50,50 48,0 52,0"
                transform={`rotate(${i * 22.5} 50 50)`}
              />
            ))}
          </svg>
        </div>
      )}

      <div className="relative w-full max-w-sm flex flex-col items-center text-center my-auto z-10 py-4">
        {/* PHASE 1 & 2: CHEST DISPLAY & TAP TO OPEN */}
        {phase !== 'revealed' && (
          <div className="flex flex-col items-center w-full">
            {/* Rarity Ribbon Header */}
            <div className="mb-3">
              {isLegendary ? (
                <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-gradient-to-r from-purple-600 via-pink-600 to-amber-500 shadow-2xl shadow-purple-500/60 border-2 border-yellow-300 text-white font-clash text-sm uppercase tracking-wider animate-bounce">
                  <Sparkles className="w-4 h-4 text-yellow-200 fill-yellow-200 animate-spin-slow" />
                  <span>¡COFRE LEGENDARIO!</span>
                  <Sparkles className="w-4 h-4 text-yellow-200 fill-yellow-200 animate-spin-slow" />
                </div>
              ) : (
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-amber-800 via-amber-700 to-amber-900 border-2 border-amber-400/70 text-amber-200 font-clash text-xs uppercase tracking-wider shadow-lg">
                  <Flame className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                  <span>COFRE DE PARTICIPACIÓN</span>
                  <Flame className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                </div>
              )}
            </div>

            {/* Tap instruction */}
            <h2
              style={customFont}
              className="text-2xl xs:text-3xl font-clash text-white text-stroke-gold mb-5 drop-shadow-lg"
            >
              {phase === 'opening'
                ? '¡Abriendo cofre...!'
                : '¡Toca el cofre para abrir!'}
            </h2>

            {/* Chest Container with realistic physics and impact effects */}
            <div className="relative w-full flex items-center justify-center my-2">
              {/* Expanding Shockwave Rings */}
              <div
                className={`absolute w-60 h-20 rounded-full border-2 border-cyan-400/80 -bottom-3 pointer-events-none transition-all duration-700 ${
                  shockwaveActive
                    ? 'scale-150 opacity-0'
                    : phase === 'opening'
                    ? 'scale-175 opacity-0'
                    : 'scale-90 opacity-60 animate-pulse'
                }`}
              />
              <div
                className={`absolute w-48 h-16 rounded-full border border-yellow-300/60 -bottom-3 pointer-events-none transition-all duration-700 ${
                  shockwaveActive ? 'scale-125 opacity-0' : 'scale-95 opacity-40'
                }`}
              />

              {/* Clickable Chest Visual with 3D drop and opening burst */}
              <div
                onClick={handleChestTap}
                className={`cursor-pointer transform select-none transition-transform duration-200 ${
                  phase === 'falling'
                    ? 'animate-chest-drop'
                    : phase === 'opening'
                    ? 'animate-chest-burst'
                    : shaking
                    ? 'animate-chest-shake scale-110'
                    : 'hover:scale-105 active:scale-95'
                }`}
              >
                {isLegendary ? (
                  <DetailedLegendaryChest
                    phase={phase}
                    shaking={shaking}
                  />
                ) : (
                  <DetailedWoodenChest
                    phase={phase}
                    shaking={shaking}
                  />
                )}
              </div>
            </div>

            {/* Tap Action Button */}
            <button
              onClick={handleChestTap}
              disabled={phase === 'opening'}
              style={customFont}
              className={`mt-6 px-8 py-3.5 rounded-2xl font-clash text-lg shadow-2xl transition-all duration-200 flex items-center gap-2.5 cursor-pointer active:scale-95 ${
                phase === 'opening'
                  ? 'opacity-80 scale-95 pointer-events-none'
                  : isLegendary
                  ? 'bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-500 hover:from-yellow-200 hover:to-amber-400 text-slate-950 border-2 border-yellow-100 shadow-yellow-500/50 ring-4 ring-purple-500/40 animate-pulse'
                  : 'bg-gradient-to-b from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 border-2 border-amber-200 shadow-amber-900/50 ring-4 ring-amber-500/20'
              }`}
            >
              <Gift className="w-5 h-5 text-slate-950" />
              <span>{phase === 'opening' ? '¡ABRIENDO...!' : '¡TOCAR PARA ABRIR!'}</span>
            </button>
            <p className="text-xs text-slate-400 mt-2 font-medium">Toca el cofre o presiona el botón</p>
          </div>
        )}

        {/* PHASE 3: REVEALED PRIZE / NO PRIZE DIALOG WITH CARD EMERGENCE */}
        {phase === 'revealed' && (
          <div className="w-full flex flex-col items-center animate-in zoom-in-95 duration-500">
            {isLegendary ? (
              /* LEGENDARY PRIZE CARD & DIALOG */
              <div className="w-full bg-gradient-to-b from-slate-900/95 via-purple-950/95 to-slate-900/95 border-2 border-amber-400/90 rounded-3xl p-5 shadow-2xl shadow-purple-900/80 backdrop-blur-xl relative overflow-hidden animate-card-float">
                {/* Ornate corner gems */}
                <div className="absolute top-2.5 left-2.5 w-3.5 h-3.5 bg-amber-400 rotate-45 border border-white shadow-sm" />
                <div className="absolute top-2.5 right-2.5 w-3.5 h-3.5 bg-amber-400 rotate-45 border border-white shadow-sm" />
                <div className="absolute bottom-2.5 left-2.5 w-3.5 h-3.5 bg-amber-400 rotate-45 border border-white shadow-sm" />
                <div className="absolute bottom-2.5 right-2.5 w-3.5 h-3.5 bg-amber-400 rotate-45 border border-white shadow-sm" />

                {/* Banner */}
                <div className="relative mb-2">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-gradient-to-r from-amber-500 via-pink-500 to-purple-600 border border-yellow-200 shadow-md">
                    <img
                      src="/assets/chests/legendary_open.png"
                      alt="Cofre"
                      className="w-5 h-5 object-contain inline"
                    />
                    <span className="font-clash text-xs tracking-widest text-white drop-shadow">
                      PREMIO LEGENDARIO
                    </span>
                  </div>
                  <h1
                    style={customFont}
                    className="text-3xl font-clash text-amber-300 text-stroke-gold mt-1.5 tracking-wide"
                  >
                    ¡FELICIDADES!
                  </h1>
                  <p className="text-xs text-purple-200 font-medium">
                    ¡Has desbloqueado una recompensa especial!
                  </p>
                </div>

                {/* 3D Prize Card with Image */}
                <div className="relative my-3 mx-auto w-full max-w-[240px] aspect-[4/3] rounded-2xl overflow-hidden border-2 border-yellow-400 shadow-2xl bg-slate-950 group ring-4 ring-purple-500/40">
                  <img
                    src={prize.imageUrl}
                    alt={prize.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=500&q=80';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent flex items-end p-2.5">
                    <div className="w-full text-left">
                      <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                        Recompensa Ganada
                      </span>
                      <p
                        style={customFont}
                        className="text-white font-clash text-base leading-tight truncate"
                      >
                        {prize.name}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Prize description */}
                {prize.description && (
                  <p className="text-xs text-slate-300 px-2 mb-3">
                    {prize.description}
                  </p>
                )}

                {/* Registered Phone Badge */}
                <div className="bg-slate-950/80 border border-purple-500/40 rounded-xl p-2.5 my-2.5 text-center shadow-inner">
                  <p className="text-xs text-slate-300">
                    Premio registrado a: <span className="font-mono font-bold text-amber-300">+{spinRecord.phoneNumber}</span>
                  </p>
                </div>

                {/* Instructions */}
                {claimInstructions && (
                  <p className="text-[11px] text-purple-200/90 bg-purple-950/60 rounded-lg p-2 my-2 border border-purple-800/40">
                    💡 {claimInstructions}
                  </p>
                )}

                {/* Action buttons */}
                <div className="flex flex-col gap-2 mt-4">
                  <button
                    onClick={handleShareWhatsApp}
                    style={customFont}
                    className="w-full py-2.5 px-4 rounded-xl font-clash text-sm text-white bg-gradient-to-r from-emerald-600 to-green-500 hover:from-emerald-500 hover:to-green-400 shadow-lg shadow-green-900/40 flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer"
                  >
                    <Share2 className="w-4 h-4" />
                    Compartir en WhatsApp
                  </button>

                  <button
                    onClick={onClose}
                    style={customFont}
                    className="w-full py-2.5 px-4 rounded-xl font-clash text-sm text-slate-950 bg-gradient-to-b from-yellow-300 to-amber-400 hover:from-yellow-200 hover:to-amber-300 border border-yellow-200 shadow-md transition active:scale-95 cursor-pointer"
                  >
                    ¡Entendido, gracias!
                  </button>
                </div>
              </div>
            ) : (
              /* NORMAL / NO PRIZE CARD & DIALOG (with Fireworks & Celebration) */
              <div className="w-full bg-gradient-to-b from-slate-900/95 via-slate-800/95 to-slate-900/95 border-2 border-amber-500/60 rounded-3xl p-5 shadow-2xl backdrop-blur-xl animate-card-float">
                {/* Header */}
                <div className="mb-2">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-300 font-clash text-xs uppercase mb-2">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>¡GRACIAS POR PARTICIPAR!</span>
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <h1
                    style={customFont}
                    className="text-2xl font-clash text-slate-100 text-stroke-sm"
                  >
                    {noPrizeConfig.title || '¡Oh no! Cofre Vacío'}
                  </h1>
                </div>

                {/* Configured No-Prize Image - Shows completely without cropping */}
                <div className="relative my-3 mx-auto w-full max-w-[270px] rounded-2xl overflow-hidden border-2 border-slate-700/80 shadow-2xl bg-slate-950 p-2 flex flex-col items-center justify-center">
                  <img
                    src={noPrizeConfig.imageUrl}
                    alt="Sin premio"
                    className="w-auto h-auto max-h-[220px] max-w-full object-contain rounded-xl drop-shadow-md"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1579208575657-c595a053b977?auto=format&fit=crop&w=500&q=80';
                    }}
                  />
                  <div className="pt-2 pb-0.5 text-center">
                    <span className="text-xs text-amber-300 font-bold tracking-wide">
                      ¡Suerte para la próxima!
                    </span>
                  </div>
                </div>

                {/* Message */}
                <p className="text-xs text-slate-300 my-2 leading-relaxed px-2">
                  {noPrizeConfig.message ||
                    'Esta vez no hubo suerte, pero agradecemos mucho tu participación en nuestra ruleta.'}
                </p>

                <div className="text-[11px] text-slate-400 bg-slate-800/60 rounded-xl p-2.5 mb-3 border border-slate-700/60">
                  Número registrado: <span className="text-white font-mono font-bold">+{spinRecord.phoneNumber}</span> (Ya utilizado)
                </div>

                {/* Action button */}
                <button
                  onClick={onClose}
                  style={customFont}
                  className="w-full py-2.5 px-4 rounded-xl font-clash text-sm text-slate-950 bg-gradient-to-b from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 border border-amber-300 transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer font-bold shadow-md"
                >
                  Regresar al Inicio
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

/* =========================================================================
   DETAILED CLASH ROYALE LEGENDARY CHEST COMPONENT
   ========================================================================= */
interface DetailedChestProps {
  phase: ChestPhase;
  shaking: boolean;
}

const DetailedLegendaryChest: React.FC<DetailedChestProps> = ({ phase, shaking }) => {
  const isOpening = phase === 'opening';

  return (
    <div className="relative w-72 h-72 xs:w-80 xs:h-80 flex items-center justify-center select-none">
      {/* 1. Magical Prismatic Aura Glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div
          className={`w-96 h-96 rounded-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cyan-400/60 via-purple-600/40 to-transparent blur-3xl transition-all duration-700 ${
            isOpening ? 'scale-150 opacity-100 animate-spin-slow' : 'scale-100 opacity-60 animate-glow-pulse'
          }`}
        />
        <div
          className={`absolute w-80 h-80 rounded-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-400/50 via-pink-500/30 to-transparent blur-2xl transition-all duration-700 ${
            isOpening ? 'scale-140 opacity-90' : 'scale-75 opacity-40'
          }`}
        />
      </div>

      {/* 2. Rotating Radiant Sunburst Light Beams */}
      <div
        className={`absolute inset-0 flex items-center justify-center pointer-events-none transition-all duration-700 ${
          isOpening ? 'opacity-100 scale-125' : 'opacity-30 scale-90'
        }`}
      >
        <svg
          className="w-80 h-80 animate-spin-slow text-yellow-300"
          viewBox="0 0 100 100"
          fill="currentColor"
        >
          {Array.from({ length: 20 }).map((_, i) => (
            <polygon
              key={i}
              points="50,50 48.5,0 51.5,0"
              transform={`rotate(${i * 18} 50 50)`}
              opacity={isOpening ? 0.75 : 0.25}
            />
          ))}
        </svg>
      </div>

      {/* 3. Shadow under chest */}
      <div
        className={`absolute bottom-4 w-56 h-10 rounded-full bg-black/85 blur-md pointer-events-none transition-all duration-500 ${
          isOpening ? 'scale-120 opacity-90' : shaking ? 'scale-110 opacity-95' : 'scale-100 opacity-70'
        }`}
      />

      {/* 4. Upward Erupting Treasure Light Pillar and Icons during Opening */}
      {isOpening && (
        <div className="absolute -top-16 inset-x-0 h-72 pointer-events-none z-30 flex items-center justify-center overflow-visible">
          {/* Vertical core golden/cyan light shaft */}
          <div className="w-48 h-full bg-gradient-to-t from-yellow-300/80 via-cyan-300/60 to-transparent blur-md animate-pulse" />
          <div className="absolute w-28 h-full bg-gradient-to-t from-white via-yellow-200 to-transparent blur-sm" />

          {/* Floating animated treasure items erupting from the chest */}
          <div className="absolute inset-0 flex items-center justify-center">
            {/* 👑 Golden Royal Crown */}
            <div className="absolute -top-6 animate-bounce text-yellow-300 filter drop-shadow-[0_0_14px_rgba(250,204,21,1)]">
              <Crown className="w-14 h-14 fill-amber-300 stroke-yellow-100 stroke-[2.5]" />
            </div>

            {/* 💎 Cyan Gem floating left */}
            <div
              className="absolute -left-4 top-2 animate-ping text-cyan-300 filter drop-shadow-[0_0_12px_rgba(6,182,212,1)]"
              style={{ animationDuration: '1.2s' }}
            >
              <Gem className="w-9 h-9 fill-cyan-200 stroke-cyan-100" />
            </div>

            {/* 🪙 Golden Coins floating right */}
            <div
              className="absolute -right-4 top-0 animate-bounce text-amber-300 filter drop-shadow-[0_0_12px_rgba(245,158,11,1)]"
              style={{ animationDuration: '1.1s' }}
            >
              <Coins className="w-9 h-9 fill-yellow-400 stroke-amber-200" />
            </div>

            {/* Sparkling stars */}
            <div className="absolute top-6 left-4 text-pink-300 animate-pulse">
              <Sparkles className="w-6 h-6 fill-pink-300" />
            </div>
            <div className="absolute top-8 right-4 text-yellow-200 animate-pulse">
              <Sparkles className="w-7 h-7 fill-yellow-200" />
            </div>
          </div>
        </div>
      )}

      {/* 5. Chest Graphic: Transitions from closed high-res render to opened burst render */}
      <div className="relative z-20 w-64 h-64 xs:w-72 xs:h-72 flex items-center justify-center">
        {isOpening ? (
          /* OPEN CHEST RENDER */
          <div className="relative w-full h-full flex items-center justify-center animate-in zoom-in-105 duration-300">
            <img
              src="/assets/chests/legendary_open.png"
              alt="Cofre Legendario Abierto"
              className="w-full h-full object-contain filter drop-shadow-[0_15px_30px_rgba(0,0,0,0.9)] drop-shadow-[0_0_35px_rgba(34,211,238,0.7)]"
            />
            {/* Radiant core flare */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-32 h-32 rounded-full bg-cyan-300/40 blur-xl animate-ping" />
            </div>
          </div>
        ) : (
          /* CLOSED CHEST RENDER */
          <div className="relative w-full h-full flex items-center justify-center group">
            {/* Ornate rounded container with crystal border */}
            <div className="w-56 h-56 xs:w-64 xs:h-64 rounded-3xl overflow-hidden p-1 bg-gradient-to-tr from-cyan-500 via-purple-600 to-amber-400 shadow-2xl shadow-cyan-500/40 relative">
              <img
                src="/assets/chests/legendary_closed.jpg"
                alt="Cofre Legendario Cerrado"
                className="w-full h-full object-cover rounded-[22px] transition-transform duration-300 group-hover:scale-105"
              />

              {/* Shimmer overlay sweep */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/20 to-transparent pointer-events-none opacity-60 group-hover:opacity-100 transition-opacity" />

              {/* Glowing animated cyan crown lock emblem overlay */}
              <div className="absolute bottom-6 left-1/2 -translate-x-1/2 p-2 rounded-xl bg-slate-950/80 border border-cyan-400/80 shadow-[0_0_15px_rgba(34,211,238,0.8)] flex items-center gap-1.5 backdrop-blur-sm pointer-events-none animate-pulse">
                <Crown className="w-4 h-4 text-cyan-300 fill-cyan-400" />
                <span className="text-[10px] font-clash text-cyan-200 tracking-wider">TOCAR PARA ABRIR</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/* =========================================================================
   DETAILED WOODEN / PARTICIPATION CHEST COMPONENT
   ========================================================================= */
const DetailedWoodenChest: React.FC<DetailedChestProps> = ({ phase, shaking }) => {
  const isOpening = phase === 'opening';

  return (
    <div className="relative w-72 h-72 xs:w-80 xs:h-80 flex items-center justify-center select-none">
      {/* 1. Warm Golden Amber Glow Aura */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div
          className={`w-88 h-88 rounded-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-500/50 via-orange-950/40 to-transparent blur-3xl transition-all duration-700 ${
            isOpening ? 'scale-140 opacity-100 animate-spin-slow' : 'scale-90 opacity-60 animate-glow-pulse'
          }`}
        />
      </div>

      {/* 2. Rotating Radiant Sunburst Light Beams */}
      <div
        className={`absolute inset-0 flex items-center justify-center pointer-events-none transition-all duration-700 ${
          isOpening ? 'opacity-90 scale-120' : 'opacity-20 scale-85'
        }`}
      >
        <svg
          className="w-72 h-72 animate-spin-slow text-amber-400"
          viewBox="0 0 100 100"
          fill="currentColor"
        >
          {Array.from({ length: 16 }).map((_, i) => (
            <polygon
              key={i}
              points="50,50 48,0 52,0"
              transform={`rotate(${i * 22.5} 50 50)`}
              opacity={isOpening ? 0.7 : 0.2}
            />
          ))}
        </svg>
      </div>

      {/* 3. Shadow under chest */}
      <div
        className={`absolute bottom-4 w-52 h-9 rounded-full bg-black/85 blur-md pointer-events-none transition-all duration-500 ${
          isOpening ? 'scale-120 opacity-90' : shaking ? 'scale-110 opacity-95' : 'scale-100 opacity-70'
        }`}
      />

      {/* 4. Golden Sparks and Particles during Opening */}
      {isOpening && (
        <div className="absolute -top-12 inset-x-0 h-64 pointer-events-none z-30 flex items-center justify-center overflow-visible">
          {/* Vertical golden light shaft */}
          <div className="w-36 h-full bg-gradient-to-t from-amber-400/80 via-yellow-200/50 to-transparent blur-md animate-pulse" />

          {/* Floating animated spark coins & flames */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="absolute -top-4 animate-bounce text-amber-300 filter drop-shadow-[0_0_12px_rgba(245,158,11,1)]">
              <Coins className="w-12 h-12 fill-yellow-400 stroke-amber-200" />
            </div>
            <div className="absolute -left-3 top-3 animate-ping text-yellow-300" style={{ animationDuration: '1.3s' }}>
              <Sparkles className="w-7 h-7 fill-yellow-200" />
            </div>
            <div className="absolute -right-3 top-2 animate-bounce text-amber-400" style={{ animationDuration: '1.2s' }}>
              <Flame className="w-8 h-8 fill-amber-500 text-yellow-200" />
            </div>
          </div>
        </div>
      )}

      {/* 5. Chest Graphic: Transitions from closed high-res render to opened burst render */}
      <div className="relative z-20 w-64 h-64 xs:w-72 xs:h-72 flex items-center justify-center">
        {isOpening ? (
          /* OPEN WOODEN CHEST RENDER */
          <div className="relative w-56 h-56 xs:w-64 xs:h-64 rounded-3xl overflow-hidden p-1 bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-700 shadow-2xl shadow-amber-500/40 animate-in zoom-in-105 duration-300">
            <img
              src="/assets/chests/wooden_open.jpg"
              alt="Cofre de Madera Abierto"
              className="w-full h-full object-cover rounded-[22px] filter drop-shadow-[0_15px_30px_rgba(0,0,0,0.9)]"
            />
            {/* Radiant core flare */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-28 h-28 rounded-full bg-amber-300/40 blur-xl animate-ping" />
            </div>
          </div>
        ) : (
          /* CLOSED WOODEN CHEST RENDER */
          <div className="relative w-full h-full flex items-center justify-center group">
            <div className="w-56 h-56 xs:w-64 xs:h-64 rounded-3xl overflow-hidden p-1 bg-gradient-to-tr from-amber-700 via-amber-500 to-slate-700 shadow-2xl shadow-amber-700/40 relative">
              <img
                src="/assets/chests/wooden_closed.jpg"
                alt="Cofre de Madera Cerrado"
                className="w-full h-full object-cover rounded-[22px] transition-transform duration-300 group-hover:scale-105"
              />

              {/* Shimmer overlay */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-amber-200/20 to-transparent pointer-events-none opacity-50 group-hover:opacity-100 transition-opacity" />

              {/* Glowing padlock prompt overlay */}
              <div className="absolute bottom-6 left-1/2 -translate-x-1/2 p-2 rounded-xl bg-slate-950/80 border border-amber-400/80 shadow-[0_0_15px_rgba(245,158,11,0.8)] flex items-center gap-1.5 backdrop-blur-sm pointer-events-none animate-pulse">
                <Flame className="w-4 h-4 text-amber-300 fill-amber-400" />
                <span className="text-[10px] font-clash text-amber-200 tracking-wider">TOCAR PARA ABRIR</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
