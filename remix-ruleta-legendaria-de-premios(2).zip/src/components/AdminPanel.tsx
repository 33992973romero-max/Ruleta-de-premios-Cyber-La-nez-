import React, { useState } from 'react';
import {
  Users,
  Award,
  Settings,
  Plus,
  Trash2,
  Edit2,
  Download,
  Search,
  CheckCircle,
  Upload,
  ArrowLeft,
  Sparkles,
  Eye,
  Shield,
  Gift,
  AlertTriangle,
  Check,
  Palette,
  Type,
  Image as ImageIcon,
  RotateCcw,
  Save,
  Crown,
} from 'lucide-react';
import { AdminSettings, Prize, SpinRecord, ThemeConfig } from '../types/game';
import { sound } from '../utils/sound';
import { storage, DEFAULT_THEME } from '../utils/storage';

interface AdminPanelProps {
  prizes: Prize[];
  history: SpinRecord[];
  settings: AdminSettings;
  onUpdatePrizes: (newPrizes: Prize[]) => void;
  onUpdateSettings: (newSettings: AdminSettings) => void;
  onDeleteRecord: (id: string) => void;
  onToggleClaimed: (id: string) => void;
  onClearHistory: () => void;
  onTestChest: (prize: Prize) => void;
  onClose: () => void;
}

type TabType = 'history' | 'prizes' | 'design' | 'settings';

interface ConfirmDialogState {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  danger?: boolean;
  onConfirm: () => void;
}

const PRESET_IMAGES = [
  { name: 'PlayStation 5', url: 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?auto=format&fit=crop&w=500&q=80' },
  { name: 'iPhone Pro', url: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=500&q=80' },
  { name: 'Tarjeta Regalo', url: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=500&q=80' },
  { name: 'Audífonos', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=500&q=80' },
  { name: 'Comida / Combo', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=500&q=80' },
  { name: 'Descuento', url: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=500&q=80' },
  { name: 'Dinero / Efectivo', url: 'https://images.unsplash.com/photo-1580519542036-c47de6196ba5?auto=format&fit=crop&w=500&q=80' },
  { name: 'Trofeo de Oro', url: 'https://images.unsplash.com/photo-1578269174936-2709b6aeb913?auto=format&fit=crop&w=500&q=80' },
  { name: 'Tristeza / Sin Premio', url: 'https://images.unsplash.com/photo-1579208575657-c595a053b977?auto=format&fit=crop&w=500&q=80' },
];

const PRESET_COLORS = [
  '#ef4444', '#f97316', '#f59e0b', '#10b981', '#06b6d4',
  '#3b82f6', '#6366f1', '#8b5cf6', '#ec4899', '#64748b',
];

const FONT_OPTIONS = [
  { id: "'Luckiest Guy', cursive, sans-serif", name: 'Clash Royale Arcade (Luckiest Guy)' },
  { id: "'Bungee', cursive, sans-serif", name: 'Arcade 3D (Bungee)' },
  { id: "'Cinzel', serif", name: 'Épica / Medieval (Cinzel)' },
  { id: "'Russo One', sans-serif", name: 'Gamer Potente (Russo One)' },
  { id: "'Fredoka', sans-serif", name: 'Amigable (Fredoka)' },
  { id: "'Bebas Neue', sans-serif", name: 'Cartel Impacto (Bebas Neue)' },
  { id: "'Teko', sans-serif", name: 'Deportiva (Teko)' },
  { id: "'Plus Jakarta Sans', sans-serif", name: 'Moderna Limpia (Jakarta)' },
];

const COLOR_PRESETS = [
  '#ffffff', '#fbbf24', '#f59e0b', '#60a5fa', '#38bdf8', '#a855f7', '#ec4899', '#34d399', '#cbd5e1'
];

export const AdminPanel: React.FC<AdminPanelProps> = ({
  prizes,
  history,
  settings,
  onUpdatePrizes,
  onUpdateSettings,
  onDeleteRecord,
  onToggleClaimed,
  onClearHistory,
  onTestChest,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('history');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'prizes' | 'noprize'>('all');

  // Prize editing modal state
  const [editingPrize, setEditingPrize] = useState<Prize | null>(null);
  const [isNewPrize, setIsNewPrize] = useState(false);

  // In-app Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Custom confirmation modal
  const [confirmDialog, setConfirmDialog] = useState<ConfirmDialogState>({
    isOpen: false,
    title: '',
    message: '',
    confirmLabel: 'Confirmar',
    onConfirm: () => {},
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 3500);
  };

  const [isSaving, setIsSaving] = useState(false);

  const handleSaveChanges = async () => {
    sound.playClick();
    setIsSaving(true);
    try {
      await storage.saveSettings(settings);
      await storage.savePrizes(prizes);
      onUpdateSettings(settings);
      onUpdatePrizes(prizes);
      showToast('✅ ¡Todos los cambios han sido guardados exitosamente!');
    } catch {
      showToast('Cambios guardados en memoria.');
    } finally {
      setTimeout(() => setIsSaving(false), 600);
    }
  };

  const themeConfig: ThemeConfig = settings.themeConfig || DEFAULT_THEME;

  const handleUpdateTheme = (updated: Partial<ThemeConfig>) => {
    const newTheme: ThemeConfig = {
      ...themeConfig,
      ...updated,
    };
    onUpdateSettings({
      ...settings,
      themeConfig: newTheme,
    });
  };

  // Stats calculation
  const totalSpins = history.length;
  const totalPrizeWinners = history.filter((h) => h.isPrize).length;
  const totalNoPrize = totalSpins - totalPrizeWinners;
  const winRate = totalSpins > 0 ? Math.round((totalPrizeWinners / totalSpins) * 100) : 0;

  // Filter history
  const filteredHistory = history.filter((record) => {
    const matchesSearch =
      record.phoneNumber.includes(searchTerm.trim()) ||
      record.prizeName.toLowerCase().includes(searchTerm.toLowerCase());
    if (!matchesSearch) return false;
    if (filterType === 'prizes') return record.isPrize;
    if (filterType === 'noprize') return !record.isPrize;
    return true;
  });

  const totalWeight = prizes.reduce((sum, p) => sum + (p.weight || 1), 0);

  // Clear all history modal
  const promptClearAllHistory = () => {
    sound.playClick();
    if (history.length === 0) {
      showToast('El historial ya está vacío.');
      return;
    }

    setConfirmDialog({
      isOpen: true,
      title: '¿Vaciar Todo el Historial?',
      message: `Se eliminarán permanentemente los ${history.length} registros de participantes. Todos los números quedarán habilitados para volver a jugar.`,
      confirmLabel: 'Sí, vaciar todo el historial',
      danger: true,
      onConfirm: () => {
        sound.playClick();
        onClearHistory();
        setConfirmDialog((prev) => ({ ...prev, isOpen: false }));
        showToast('¡Historial vaciado! Todos los números pueden jugar de nuevo.');
      },
    });
  };

  // Delete single record modal
  const promptDeleteRecord = (record: SpinRecord) => {
    sound.playClick();
    setConfirmDialog({
      isOpen: true,
      title: '¿Eliminar este registro?',
      message: `Se eliminará la participación del teléfono +${record.phoneNumber} (Premio: "${record.prizeName}"). Esto le permitirá volver a girar la ruleta.`,
      confirmLabel: 'Eliminar y permitir nuevo giro',
      danger: true,
      onConfirm: () => {
        sound.playClick();
        onDeleteRecord(record.id);
        setConfirmDialog((prev) => ({ ...prev, isOpen: false }));
        showToast(`Registro de +${record.phoneNumber} eliminado. Ya puede girar.`);
      },
    });
  };

  // Export CSV
  const handleExportCSV = () => {
    sound.playClick();
    if (history.length === 0) {
      showToast('No hay registros de juegos para exportar.');
      return;
    }

    const headers = ['Telefono', 'Premio', 'Es_Premio', 'Tipo_Cofre', 'Canjeado', 'Fecha_Hora'];
    const rows = history.map((r) => [
      `"${r.phoneNumber}"`,
      `"${r.prizeName.replace(/"/g, '""')}"`,
      r.isPrize ? 'SI' : 'NO',
      r.chestType,
      r.claimed ? 'SI' : 'NO',
      `"${new Date(r.timestamp).toLocaleString('es-ES')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `historial_ruleta_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Archivo CSV descargado con éxito.');
  };

  // Handle generic file upload (headerLogo, wheelLogo, prize, noprize) with server persistence
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'prize' | 'noprize' | 'wheelLogo' | 'headerLogo') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      showToast('La imagen no debe superar los 10MB.');
      return;
    }

    showToast('Subiendo y guardando imagen en el servidor...');

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;
      // Upload to server so it is hosted permanently as a public URL
      const publicUrl = await storage.uploadImage(base64Data, target);

      if (target === 'prize' && editingPrize) {
        setEditingPrize({ ...editingPrize, imageUrl: publicUrl });
        showToast('Foto subida y guardada en el servidor.');
      } else if (target === 'noprize') {
        onUpdateSettings({
          ...settings,
          noPrizeConfig: {
            ...settings.noPrizeConfig,
            imageUrl: publicUrl,
          },
        });
        showToast('Foto de "Sin Premio" guardada en el servidor.');
      } else if (target === 'wheelLogo') {
        onUpdateSettings({
          ...settings,
          wheelCenterLogoUrl: publicUrl,
        });
        showToast('¡Logo central guardado en el servidor!');
      } else if (target === 'headerLogo') {
        onUpdateSettings({
          ...settings,
          headerLogoUrl: publicUrl,
        });
        showToast('¡Logo de cabecera guardado en el servidor!');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSavePrize = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPrize) return;

    sound.playClick();
    if (isNewPrize) {
      onUpdatePrizes([...prizes, editingPrize]);
      showToast('Nuevo premio agregado a la ruleta.');
    } else {
      onUpdatePrizes(prizes.map((p) => (p.id === editingPrize.id ? editingPrize : p)));
      showToast('Premio actualizado.');
    }
    setEditingPrize(null);
  };

  const promptDeletePrize = (prize: Prize) => {
    sound.playClick();
    if (prizes.length <= 2) {
      showToast('La ruleta debe tener al menos 2 sectores para funcionar.');
      return;
    }
    setConfirmDialog({
      isOpen: true,
      title: '¿Eliminar este premio?',
      message: `¿Seguro que deseas eliminar "${prize.name}" de la ruleta?`,
      confirmLabel: 'Eliminar premio',
      danger: true,
      onConfirm: () => {
        sound.playClick();
        onUpdatePrizes(prizes.filter((p) => p.id !== prize.id));
        setConfirmDialog((prev) => ({ ...prev, isOpen: false }));
        showToast(`Premio "${prize.name}" eliminado.`);
      },
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col text-slate-100 overflow-hidden animate-in fade-in duration-200">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-70 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 px-4 py-2 rounded-2xl shadow-2xl font-bold font-clash text-xs flex items-center gap-2 border border-yellow-200 animate-in slide-in-from-top duration-200">
          <Check className="w-4 h-4 stroke-[3]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Admin Header */}
      <header className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition"
            title="Volver a la ruleta"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-clash text-lg text-amber-400 flex items-center gap-2">
              <Shield className="w-5 h-5 text-amber-500" />
              Panel de Administración
            </h1>
            <p className="text-[11px] text-slate-400">PIN activo: <strong className="text-amber-300 font-mono">{settings.adminPin}</strong></p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSaveChanges}
            disabled={isSaving}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 hover:from-emerald-400 hover:to-green-400 text-white text-xs font-bold font-clash shadow-lg shadow-emerald-950/60 flex items-center gap-1.5 transition active:scale-95 cursor-pointer ring-2 ring-emerald-400/50"
            title="Guardar todos los cambios"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'GUARDANDO...' : 'GUARDAR CAMBIOS'}</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold font-clash transition"
          >
            IR A RULETA
          </button>
        </div>
      </header>

      {/* 4 Tabs Bar (Mobile scrollable) */}
      <div className="flex border-b border-slate-800 bg-slate-900/60 px-2 shrink-0 overflow-x-auto">
        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('history');
          }}
          className={`flex-1 min-w-[100px] py-3 text-xs font-clash uppercase tracking-wider flex items-center justify-center gap-1.5 border-b-2 transition ${
            activeTab === 'history'
              ? 'border-amber-400 text-amber-300 bg-amber-500/10'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          Números ({history.length})
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('prizes');
          }}
          className={`flex-1 min-w-[100px] py-3 text-xs font-clash uppercase tracking-wider flex items-center justify-center gap-1.5 border-b-2 transition ${
            activeTab === 'prizes'
              ? 'border-amber-400 text-amber-300 bg-amber-500/10'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          Premios ({prizes.length})
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('design');
          }}
          className={`flex-1 min-w-[120px] py-3 text-xs font-clash uppercase tracking-wider flex items-center justify-center gap-1.5 border-b-2 transition ${
            activeTab === 'design'
              ? 'border-amber-400 text-amber-300 bg-amber-500/10'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          Diseño & Logo
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('settings');
          }}
          className={`flex-1 min-w-[110px] py-3 text-xs font-clash uppercase tracking-wider flex items-center justify-center gap-1.5 border-b-2 transition ${
            activeTab === 'settings'
              ? 'border-amber-400 text-amber-300 bg-amber-500/10'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          Ajustes & PIN
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-4 max-w-4xl mx-auto w-full">
        {/* ================= TAB 1: HISTORY / PHONE REGISTRY ================= */}
        {activeTab === 'history' && (
          <div className="space-y-4">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
                <span className="text-[11px] text-slate-400 font-semibold block uppercase">Total Giros</span>
                <span className="text-2xl font-clash text-white">{totalSpins}</span>
              </div>
              <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-3 text-center">
                <span className="text-[11px] text-emerald-400 font-semibold block uppercase">Premios Ganados</span>
                <span className="text-2xl font-clash text-emerald-400">{totalPrizeWinners}</span>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
                <span className="text-[11px] text-slate-400 font-semibold block uppercase">Sin Premio</span>
                <span className="text-2xl font-clash text-slate-300">{totalNoPrize}</span>
              </div>
              <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-3 text-center">
                <span className="text-[11px] text-amber-400 font-semibold block uppercase">Tasa de Éxito</span>
                <span className="text-2xl font-clash text-amber-400">{winRate}%</span>
              </div>
            </div>

            {/* Quick Action Banner for Clearing History */}
            {history.length > 0 && (
              <div className="bg-gradient-to-r from-rose-950/80 via-slate-900 to-rose-950/80 border border-rose-500/50 rounded-2xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
                <div className="flex items-center gap-2.5 text-center sm:text-left">
                  <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                    <Trash2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white font-clash">
                      Eliminación de Historial ({history.length} números registrados)
                    </h4>
                    <p className="text-[11px] text-slate-300">
                      Al vaciar el historial, todos los números podrán volver a girar la ruleta.
                    </p>
                  </div>
                </div>

                <button
                  onClick={promptClearAllHistory}
                  className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white rounded-xl text-xs font-clash flex items-center justify-center gap-1.5 shadow-md shadow-rose-950/60 transition active:scale-95 shrink-0 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  VACIAR TODO EL HISTORIAL
                </button>
              </div>
            )}

            {/* Filter and Search Bar */}
            <div className="flex flex-col sm:flex-row gap-2 bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar por teléfono o premio..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                <button
                  onClick={() => setFilterType('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                    filterType === 'all'
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Todos ({history.length})
                </button>
                <button
                  onClick={() => setFilterType('prizes')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                    filterType === 'prizes'
                      ? 'bg-purple-600 text-white'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  🏆 Ganadores
                </button>
                <button
                  onClick={() => setFilterType('noprize')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                    filterType === 'noprize'
                      ? 'bg-slate-700 text-white'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Sin Premio
                </button>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleExportCSV}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition shrink-0 cursor-pointer"
                  title="Descargar Excel/CSV"
                >
                  <Download className="w-3.5 h-3.5" />
                  CSV
                </button>
              </div>
            </div>

            {/* Records List (Mobile cards) */}
            {filteredHistory.length === 0 ? (
              <div className="text-center py-12 bg-slate-900/40 rounded-2xl border border-slate-800/80">
                <Users className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-400">No hay registros de jugadores</p>
                <p className="text-xs text-slate-500 mt-1">
                  Cuando alguien ingrese su número y gire la ruleta, aparecerá aquí inmediatamente.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredHistory.map((record) => (
                  <div
                    key={record.id}
                    className={`bg-slate-900 border rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition ${
                      record.isPrize
                        ? 'border-purple-500/40 shadow-lg shadow-purple-950/20'
                        : 'border-slate-800'
                    }`}
                  >
                    {/* Left info */}
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          record.isPrize
                            ? 'bg-gradient-to-tr from-purple-600 to-amber-500 text-white shadow-md'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {record.isPrize ? <Sparkles className="w-5 h-5" /> : <Gift className="w-5 h-5" />}
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-base font-bold text-white tracking-wide">
                            +{record.phoneNumber}
                          </span>
                          {record.isPrize ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
                              Legendario
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-400 border border-slate-700">
                              Normal
                            </span>
                          )}
                        </div>

                        <p className="text-sm font-clash text-amber-300 mt-0.5">
                          {record.prizeName}
                        </p>

                        <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1 flex-wrap">
                          <span>📅 {new Date(record.timestamp).toLocaleString('es-ES')}</span>
                        </div>
                      </div>
                    </div>

                    {/* Right action buttons */}
                    <div className="flex items-center gap-2 self-end sm:self-center border-t sm:border-t-0 pt-2 sm:pt-0 w-full sm:w-auto justify-end border-slate-800">
                      {record.isPrize && (
                        <button
                          onClick={() => {
                            sound.playClick();
                            onToggleClaimed(record.id);
                          }}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                            record.claimed
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                          }`}
                          title="Alternar estado de entrega del premio"
                        >
                          {record.claimed ? (
                            <>
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                              Entregado
                            </>
                          ) : (
                            <>
                              <div className="w-2 h-2 rounded-full bg-amber-400" />
                              Pendiente
                            </>
                          )}
                        </button>
                      )}

                      <button
                        onClick={() => promptDeleteRecord(record)}
                        className="px-3 py-1.5 rounded-xl text-xs bg-rose-950/70 hover:bg-rose-900 text-rose-300 border border-rose-700/80 flex items-center gap-1.5 transition active:scale-95 font-semibold cursor-pointer"
                        title="Eliminar este número y permitirle volver a jugar"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                        <span>Permitir volver a jugar</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 2: PRIZES MANAGEMENT ================= */}
        {activeTab === 'prizes' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-clash text-lg text-white">Sectores de la Ruleta</h2>
                <p className="text-xs text-slate-400">
                  Agrega, edita fotos, colores y probabilidades de cada premio.
                </p>
              </div>

              <button
                onClick={() => {
                  sound.playClick();
                  setIsNewPrize(true);
                  setEditingPrize({
                    id: `prize-${Date.now()}`,
                    name: 'Nuevo Premio',
                    description: 'Descripción del premio',
                    isPrize: true,
                    chestType: 'legendary',
                    color: PRESET_COLORS[Math.floor(Math.random() * PRESET_COLORS.length)],
                    textColor: '#ffffff',
                    weight: 10,
                    imageUrl: PRESET_IMAGES[0].url,
                    couponPrefix: 'GANADOR',
                  });
                }}
                className="px-3 py-2 bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 rounded-xl font-clash text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                AGREGAR PREMIO
              </button>
            </div>

            {/* Prizes Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {prizes.map((prize) => {
                const probPercent = Math.round(((prize.weight || 1) / totalWeight) * 100);
                return (
                  <div
                    key={prize.id}
                    className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md flex flex-col justify-between"
                  >
                    <div className="p-3.5 flex gap-3">
                      {/* Thumbnail with slice color indicator */}
                      <div className="relative w-20 h-20 rounded-xl overflow-hidden bg-slate-950 shrink-0 border-2 border-slate-700">
                        <img
                          src={prize.imageUrl}
                          alt={prize.name}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.currentTarget as HTMLImageElement).src =
                              'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=500&q=80';
                          }}
                        />
                        <div
                          className="absolute bottom-0 inset-x-0 h-2"
                          style={{ backgroundColor: prize.color }}
                        />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className="w-3 h-3 rounded-full border border-white/40"
                            style={{ backgroundColor: prize.color }}
                          />
                          <h3 className="font-clash text-sm text-white truncate">{prize.name}</h3>
                        </div>

                        {prize.description && (
                          <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                            {prize.description}
                          </p>
                        )}

                        <div className="flex items-center gap-2 mt-2 flex-wrap">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              prize.isPrize
                                ? 'bg-purple-900/60 text-purple-300 border border-purple-600'
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}
                          >
                            {prize.isPrize ? '✨ Cofre Legendario' : '📦 Cofre Común'}
                          </span>

                          <span className="text-[11px] font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                            Prob: ~{probPercent}%
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Action Bar */}
                    <div className="bg-slate-950/60 border-t border-slate-800/80 px-3 py-2 flex items-center justify-between">
                      {/* Test chest trigger button */}
                      <button
                        onClick={() => {
                          sound.playClick();
                          onTestChest(prize);
                        }}
                        className="text-[11px] font-semibold text-purple-300 hover:text-purple-200 flex items-center gap-1 transition cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Probar animación y cofre
                      </button>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            sound.playClick();
                            setIsNewPrize(false);
                            setEditingPrize({ ...prize });
                          }}
                          className="p-1.5 text-slate-300 hover:text-amber-400 rounded-lg hover:bg-slate-800 transition cursor-pointer"
                          title="Editar premio"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => promptDeletePrize(prize)}
                          className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition cursor-pointer"
                          title="Eliminar premio"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Save Changes Floating Action Bar */}
            <div className="sticky bottom-0 bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-2xl p-3 flex flex-col sm:flex-row items-center justify-between gap-2.5 shadow-2xl mt-4">
              <span className="text-xs text-slate-300 font-medium text-center sm:text-left">
                Guarda tus cambios para que se apliquen en vivo en la ruleta.
              </span>
              <button
                type="button"
                onClick={handleSaveChanges}
                disabled={isSaving}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 hover:from-emerald-400 hover:to-green-400 text-white font-clash text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-green-950/60 transition active:scale-95 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                {isSaving ? 'GUARDANDO...' : 'GUARDAR CAMBIOS'}
              </button>
            </div>
          </div>
        )}

        {/* ================= TAB 3: DESIGN, LOGO, FONTS & TEXT CONTENT ================= */}
        {activeTab === 'design' && (
          <div className="space-y-5">
            {/* 1. HEADER LOGO / CORONITA SECTION */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
              <div className="flex items-center gap-2 mb-2">
                <Crown className="w-5 h-5 text-amber-400" />
                <h3 className="font-clash text-lg text-white">Logo Superior (Sustituye la coronita dorada)</h3>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                Coloca la imagen o logo de tu empresa arriba de "Ruleta de Premios". Si no subes ninguno, se mostrará la coronita dorada por defecto.
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-4">
                {/* Header Logo Badge Preview */}
                <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 p-0.5 shadow-xl shadow-amber-500/30 flex items-center justify-center shrink-0">
                  <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center overflow-hidden p-1">
                    {settings.headerLogoUrl ? (
                      <img
                        src={settings.headerLogoUrl}
                        alt="Logo de cabecera"
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <Crown className="w-9 h-9 text-amber-400 fill-amber-400 animate-pulse" />
                    )}
                  </div>
                </div>

                <div className="flex-1 space-y-3 w-full">
                  <div className="flex flex-wrap gap-2">
                    <label className="cursor-pointer inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-clash text-xs hover:from-amber-400 hover:to-yellow-300 transition shadow-md">
                      <Upload className="w-4 h-4" />
                      SUBIR LOGO O FOTO DE CABECERA
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleFileUpload(e, 'headerLogo')}
                      />
                    </label>

                    {settings.headerLogoUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          onUpdateSettings({ ...settings, headerLogoUrl: '' });
                          showToast('Logo quitado. Se mostrará la coronita dorada.');
                        }}
                        className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition"
                      >
                        Volver a Coronita Dorada
                      </button>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      O ingresar enlace URL de la imagen/logo:
                    </label>
                    <input
                      type="url"
                      placeholder="https://ejemplo.com/logo-empresa.png"
                      value={settings.headerLogoUrl || ''}
                      onChange={(e) => {
                        onUpdateSettings({ ...settings, headerLogoUrl: e.target.value });
                      }}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 2. WHEEL CENTER LOGO SECTION */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
              <div className="flex items-center gap-2 mb-2">
                <ImageIcon className="w-5 h-5 text-amber-400" />
                <h3 className="font-clash text-lg text-white">Logo Central de la Ruleta</h3>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                Sube el logo de tu empresa o negocio para que aparezca en el centro dorado de la ruleta.
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-4">
                {/* Center Hub Preview */}
                <div className="relative w-24 h-24 rounded-full border-4 border-amber-400 bg-slate-950 p-1 flex items-center justify-center shrink-0 shadow-lg shadow-amber-500/20">
                  {settings.wheelCenterLogoUrl ? (
                    <img
                      src={settings.wheelCenterLogoUrl}
                      alt="Logo central"
                      className="w-full h-full object-cover rounded-full"
                    />
                  ) : (
                    <div className="w-full h-full rounded-full bg-gradient-to-tr from-purple-900 to-indigo-950 flex items-center justify-center border border-amber-300/40">
                      <Sparkles className="w-7 h-7 text-amber-300" />
                    </div>
                  )}
                </div>

                <div className="flex-1 space-y-3 w-full">
                  <div className="flex flex-wrap gap-2">
                    <label className="cursor-pointer inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-clash text-xs hover:from-amber-400 hover:to-yellow-300 transition shadow-md">
                      <Upload className="w-4 h-4" />
                      SUBIR LOGO (FOTO O ARCHIVO)
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleFileUpload(e, 'wheelLogo')}
                      />
                    </label>

                    {settings.wheelCenterLogoUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          onUpdateSettings({ ...settings, wheelCenterLogoUrl: '' });
                          showToast('Logo quitado. Se muestra el emblema predeterminado.');
                        }}
                        className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition"
                      >
                        Quitar Logo
                      </button>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      O pegar enlace URL del logo:
                    </label>
                    <input
                      type="url"
                      placeholder="https://ejemplo.com/logo.png"
                      value={settings.wheelCenterLogoUrl || ''}
                      onChange={(e) => {
                        onUpdateSettings({ ...settings, wheelCenterLogoUrl: e.target.value });
                      }}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 2. TYPOGRAPHY / FONT FAMILY SELECTOR */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
              <div className="flex items-center gap-2 mb-2">
                <Type className="w-5 h-5 text-amber-400" />
                <h3 className="font-clash text-lg text-white">Tipografía (Fuente de Letra)</h3>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                Elige el estilo de letra para los títulos, botones y pantallas de la ruleta.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {FONT_OPTIONS.map((f) => {
                  const isSelected = themeConfig.fontFamily === f.id;
                  return (
                    <button
                      type="button"
                      key={f.id}
                      onClick={() => {
                        sound.playClick();
                        handleUpdateTheme({ fontFamily: f.id, fontName: f.name });
                        showToast(`Fuente cambiada a: ${f.name}`);
                      }}
                      className={`p-3 rounded-2xl border text-left transition flex items-center justify-between ${
                        isSelected
                          ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/40'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div>
                        <span className="text-[11px] text-slate-400 block">{f.name}</span>
                        <span
                          className="text-base text-white font-bold block mt-0.5"
                          style={{ fontFamily: f.id }}
                        >
                          ¡GIRA Y GANA! 123
                        </span>
                      </div>
                      {isSelected && <Check className="w-5 h-5 text-amber-400 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. TEXT COLORS CUSTOMIZATION */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
              <div className="flex items-center gap-2 mb-2">
                <Palette className="w-5 h-5 text-amber-400" />
                <h3 className="font-clash text-lg text-white">Colores de Texto</h3>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                Personaliza los colores de los títulos, descripciones y acentos.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Title Color */}
                <div className="space-y-2 bg-slate-950 p-3 rounded-2xl border border-slate-800">
                  <label className="block text-xs font-semibold text-slate-300">
                    Color de Títulos:
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={themeConfig.titleColor}
                      onChange={(e) => handleUpdateTheme({ titleColor: e.target.value })}
                      className="w-8 h-8 rounded-lg border-0 cursor-pointer bg-transparent"
                    />
                    <span className="font-mono text-xs text-amber-300">{themeConfig.titleColor}</span>
                  </div>
                  <div className="flex gap-1 flex-wrap pt-1">
                    {COLOR_PRESETS.map((c) => (
                      <button
                        type="button"
                        key={c}
                        onClick={() => handleUpdateTheme({ titleColor: c })}
                        className={`w-5 h-5 rounded-full border ${
                          themeConfig.titleColor === c ? 'border-white scale-110' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>

                {/* Subtitle Color */}
                <div className="space-y-2 bg-slate-950 p-3 rounded-2xl border border-slate-800">
                  <label className="block text-xs font-semibold text-slate-300">
                    Color de Subtítulos:
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={themeConfig.subtitleColor}
                      onChange={(e) => handleUpdateTheme({ subtitleColor: e.target.value })}
                      className="w-8 h-8 rounded-lg border-0 cursor-pointer bg-transparent"
                    />
                    <span className="font-mono text-xs text-amber-300">{themeConfig.subtitleColor}</span>
                  </div>
                  <div className="flex gap-1 flex-wrap pt-1">
                    {COLOR_PRESETS.map((c) => (
                      <button
                        type="button"
                        key={c}
                        onClick={() => handleUpdateTheme({ subtitleColor: c })}
                        className={`w-5 h-5 rounded-full border ${
                          themeConfig.subtitleColor === c ? 'border-white scale-110' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>

                {/* Accent Color */}
                <div className="space-y-2 bg-slate-950 p-3 rounded-2xl border border-slate-800">
                  <label className="block text-xs font-semibold text-slate-300">
                    Color de Acento / Botones:
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={themeConfig.accentColor}
                      onChange={(e) => handleUpdateTheme({ accentColor: e.target.value })}
                      className="w-8 h-8 rounded-lg border-0 cursor-pointer bg-transparent"
                    />
                    <span className="font-mono text-xs text-amber-300">{themeConfig.accentColor}</span>
                  </div>
                  <div className="flex gap-1 flex-wrap pt-1">
                    {COLOR_PRESETS.map((c) => (
                      <button
                        type="button"
                        key={c}
                        onClick={() => handleUpdateTheme({ accentColor: c })}
                        className={`w-5 h-5 rounded-full border ${
                          themeConfig.accentColor === c ? 'border-white scale-110' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* 4. TEXT CONTENT CUSTOMIZATION */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-3.5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-clash text-lg text-white">Contenido de Textos de la Ruleta</h3>
                  <p className="text-xs text-slate-400">Edita lo que dice cada encabezado y botón.</p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    handleUpdateTheme({
                      mainTitle: DEFAULT_THEME.mainTitle,
                      subtitle: DEFAULT_THEME.subtitle,
                      bannerText: DEFAULT_THEME.bannerText,
                      spinButtonText: DEFAULT_THEME.spinButtonText,
                    });
                    showToast('Textos restablecidos a los valores predeterminados.');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 border border-slate-700"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Restablecer
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Título Principal:
                  </label>
                  <input
                    type="text"
                    value={themeConfig.mainTitle}
                    onChange={(e) => handleUpdateTheme({ mainTitle: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Texto del Banner Superior (Opcional):
                  </label>
                  <input
                    type="text"
                    placeholder="Opcional (dejar vacío para no mostrar)"
                    value={themeConfig.bannerText}
                    onChange={(e) => handleUpdateTheme({ bannerText: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Subtítulo / Eslogan Explicativo:
                  </label>
                  <input
                    type="text"
                    value={themeConfig.subtitle}
                    onChange={(e) => handleUpdateTheme({ subtitle: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Texto del Botón de Giro:
                  </label>
                  <input
                    type="text"
                    value={themeConfig.spinButtonText}
                    onChange={(e) => handleUpdateTheme({ spinButtonText: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>
            </div>

            {/* Save Changes Floating Action Bar */}
            <div className="sticky bottom-0 bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-2xl p-3 flex flex-col sm:flex-row items-center justify-between gap-2.5 shadow-2xl mt-4">
              <span className="text-xs text-slate-300 font-medium text-center sm:text-left">
                Guarda tus cambios de diseño, fuentes y colores.
              </span>
              <button
                type="button"
                onClick={handleSaveChanges}
                disabled={isSaving}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 hover:from-emerald-400 hover:to-green-400 text-white font-clash text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-green-950/60 transition active:scale-95 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                {isSaving ? 'GUARDANDO...' : 'GUARDAR CAMBIOS'}
              </button>
            </div>
          </div>
        )}

        {/* ================= TAB 4: SETTINGS, PIN & NO-PRIZE PHOTO CONFIG ================= */}
        {activeTab === 'settings' && (
          <div className="space-y-5">
            {/* NO PRIZE CUSTOM PHOTO SECTION */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
              <div className="flex items-center gap-2 mb-3">
                <Gift className="w-5 h-5 text-amber-400" />
                <h3 className="font-clash text-lg text-white">
                  Foto y Mensaje para "Sin Premio" (Cofre Normal)
                </h3>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                Esta es la foto y texto que verá el participante cuando le toque un cofre normal sin premio.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 items-start">
                {/* Photo Preview - Complete uncropped view */}
                <div className="relative w-36 h-28 rounded-2xl overflow-hidden bg-slate-950 border-2 border-slate-700 shrink-0 mx-auto sm:mx-0 p-1 flex items-center justify-center">
                  <img
                    src={settings.noPrizeConfig.imageUrl}
                    alt="Sin premio"
                    className="w-full h-full object-contain rounded-xl"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1579208575657-c595a053b977?auto=format&fit=crop&w=500&q=80';
                    }}
                  />
                </div>

                <div className="flex-1 space-y-3 w-full">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Subir foto desde tu celular o computadora:
                    </label>
                    <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-clash hover:bg-amber-500/30 transition">
                      <Upload className="w-4 h-4" />
                      SUBIR FOTO (GALERÍA O CÁMARA)
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleFileUpload(e, 'noprize')}
                      />
                    </label>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      O ingresar URL de imagen:
                    </label>
                    <input
                      type="url"
                      value={settings.noPrizeConfig.imageUrl}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          noPrizeConfig: {
                            ...settings.noPrizeConfig,
                            imageUrl: e.target.value,
                          },
                        })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Título del cuadro de diálogo:
                      </label>
                      <input
                        type="text"
                        value={settings.noPrizeConfig.title}
                        onChange={(e) =>
                          onUpdateSettings({
                            ...settings,
                            noPrizeConfig: {
                              ...settings.noPrizeConfig,
                              title: e.target.value,
                            },
                          })
                        }
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Mensaje de consuelo:
                      </label>
                      <input
                        type="text"
                        value={settings.noPrizeConfig.message}
                        onChange={(e) =>
                          onUpdateSettings({
                            ...settings,
                            noPrizeConfig: {
                              ...settings.noPrizeConfig,
                              message: e.target.value,
                            },
                          })
                        }
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* STORE / GENERAL SETTINGS & PIN */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-4">
              <h3 className="font-clash text-lg text-white">Ajustes Generales y Seguridad</h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Nombre del Negocio / Ruleta:
                  </label>
                  <input
                    type="text"
                    value={settings.storeName}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, storeName: e.target.value })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    PIN de Administrador:
                  </label>
                  <input
                    type="text"
                    maxLength={8}
                    value={settings.adminPin}
                    onChange={(e) => {
                      const newPin = e.target.value;
                      onUpdateSettings({ ...settings, adminPin: newPin });
                      showToast(`PIN actualizado a: ${newPin}`);
                    }}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-amber-300 font-mono font-bold focus:outline-none focus:border-amber-400"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    PIN actual: <strong className="text-amber-300 font-mono">108110</strong>
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Instrucciones para los Ganadores (aparece en el premio):
                </label>
                <textarea
                  rows={2}
                  value={settings.claimInstructions}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, claimInstructions: e.target.value })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Save Changes Floating Action Bar */}
            <div className="sticky bottom-0 bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-2xl p-3 flex flex-col sm:flex-row items-center justify-between gap-2.5 shadow-2xl mt-4">
              <span className="text-xs text-slate-300 font-medium text-center sm:text-left">
                Guarda los ajustes de nombre, PIN y mensaje.
              </span>
              <button
                type="button"
                onClick={handleSaveChanges}
                disabled={isSaving}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 hover:from-emerald-400 hover:to-green-400 text-white font-clash text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-green-950/60 transition active:scale-95 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                {isSaving ? 'GUARDANDO...' : 'GUARDAR CAMBIOS'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ================= IN-APP CONFIRMATION MODAL ================= */}
      {confirmDialog.isOpen && (
        <div className="fixed inset-0 z-70 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border-2 border-rose-500/80 rounded-3xl p-5 max-w-sm w-full shadow-2xl text-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="font-clash text-lg text-white mb-2">{confirmDialog.title}</h3>
            <p className="text-xs text-slate-300 mb-5 leading-relaxed">
              {confirmDialog.message}
            </p>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setConfirmDialog((prev) => ({ ...prev, isOpen: false }))}
                className="flex-1 py-2.5 rounded-xl font-clash text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 transition cursor-pointer"
              >
                CANCELAR
              </button>
              <button
                type="button"
                onClick={confirmDialog.onConfirm}
                className="flex-1 py-2.5 rounded-xl font-clash text-xs text-white bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 shadow-lg shadow-rose-950/50 transition active:scale-95 cursor-pointer"
              >
                {confirmDialog.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= EDIT / ADD PRIZE MODAL ================= */}
      {editingPrize && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-slate-900 border-2 border-amber-500/70 rounded-3xl p-5 max-w-md w-full shadow-2xl my-auto">
            <h3 className="font-clash text-lg text-white mb-3">
              {isNewPrize ? 'Crear Nuevo Premio' : `Editar "${editingPrize.name}"`}
            </h3>

            <form onSubmit={handleSavePrize} className="space-y-3.5">
              {/* Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Nombre del Premio:
                </label>
                <input
                  type="text"
                  required
                  value={editingPrize.name}
                  onChange={(e) => setEditingPrize({ ...editingPrize, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Descripción (Opcional):
                </label>
                <input
                  type="text"
                  value={editingPrize.description || ''}
                  onChange={(e) => setEditingPrize({ ...editingPrize, description: e.target.value })}
                  placeholder="Detalles sobre el premio"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Prize Type (Real Prize vs No Prize) */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setEditingPrize({
                      ...editingPrize,
                      isPrize: true,
                      chestType: 'legendary',
                    })
                  }
                  className={`p-2.5 rounded-xl text-xs font-clash text-center border transition cursor-pointer ${
                    editingPrize.isPrize
                      ? 'bg-purple-600/30 border-purple-500 text-purple-200 ring-2 ring-purple-500/50'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  ✨ Es Premio Real
                  <span className="block text-[10px] font-sans font-normal text-purple-300">
                    Abre Cofre Legendario
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setEditingPrize({
                      ...editingPrize,
                      isPrize: false,
                      chestType: 'normal',
                    })
                  }
                  className={`p-2.5 rounded-xl text-xs font-clash text-center border transition cursor-pointer ${
                    !editingPrize.isPrize
                      ? 'bg-amber-600/30 border-amber-500 text-amber-200 ring-2 ring-amber-500/50'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  📦 Sin Premio
                  <span className="block text-[10px] font-sans font-normal text-amber-300">
                    Abre Cofre Común
                  </span>
                </button>
              </div>

              {/* Image Selection with Upload button & gallery */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Imagen del Premio:
                </label>

                <div className="flex gap-3 items-center mb-2">
                  <div className="w-14 h-14 rounded-xl overflow-hidden bg-slate-950 border border-slate-700 shrink-0">
                    <img
                      src={editingPrize.imageUrl}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 space-y-1">
                    <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition">
                      <Upload className="w-3.5 h-3.5" />
                      Subir foto de celular / PC
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleFileUpload(e, 'prize')}
                      />
                    </label>
                    <input
                      type="url"
                      placeholder="O pega URL de imagen..."
                      value={editingPrize.imageUrl}
                      onChange={(e) =>
                        setEditingPrize({ ...editingPrize, imageUrl: e.target.value })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none"
                    />
                  </div>
                </div>

                {/* Preset quick images */}
                <div className="flex gap-1.5 overflow-x-auto pb-1">
                  {PRESET_IMAGES.slice(0, 6).map((img, i) => (
                    <button
                      type="button"
                      key={i}
                      onClick={() => setEditingPrize({ ...editingPrize, imageUrl: img.url })}
                      className="w-8 h-8 rounded-lg overflow-hidden border border-slate-700 hover:border-amber-400 shrink-0 cursor-pointer"
                      title={img.name}
                    >
                      <img src={img.url} alt={img.name} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Wheel Slice Color */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Color del sector en la ruleta:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={editingPrize.color}
                    onChange={(e) => setEditingPrize({ ...editingPrize, color: e.target.value })}
                    className="w-8 h-8 rounded-lg border-0 cursor-pointer bg-transparent"
                  />
                  <div className="flex gap-1.5 flex-wrap">
                    {PRESET_COLORS.map((c) => (
                      <button
                        type="button"
                        key={c}
                        onClick={() => setEditingPrize({ ...editingPrize, color: c })}
                        className={`w-6 h-6 rounded-full border cursor-pointer ${
                          editingPrize.color === c ? 'border-white scale-110' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Weight / Probability slider */}
              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                  <span>Peso de Probabilidad:</span>
                  <span className="font-mono text-amber-400">{editingPrize.weight}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="100"
                  value={editingPrize.weight}
                  onChange={(e) =>
                    setEditingPrize({ ...editingPrize, weight: Number(e.target.value) })
                  }
                  className="w-full accent-amber-400"
                />
                <p className="text-[10px] text-slate-500 mt-0.5">
                  Mayor número = Más posibilidades de salir en la ruleta.
                </p>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingPrize(null)}
                  className="flex-1 py-2.5 rounded-xl font-clash text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 transition cursor-pointer"
                >
                  CANCELAR
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl font-clash text-xs text-slate-950 bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 shadow-md transition cursor-pointer"
                >
                  GUARDAR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
