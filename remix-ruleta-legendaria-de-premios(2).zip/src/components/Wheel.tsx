import React, { useRef, useState, useEffect } from 'react';
import { Prize } from '../types/game';
import { sound } from '../utils/sound';

interface WheelProps {
  prizes: Prize[];
  isSpinning: boolean;
  onSpinEnd: (prize: Prize) => void;
  targetPrize: Prize | null;
  centerLogoUrl?: string;
}

export const Wheel: React.FC<WheelProps> = ({
  prizes,
  isSpinning,
  onSpinEnd,
  targetPrize,
  centerLogoUrl,
}) => {
  const wheelRef = useRef<SVGSVGElement | null>(null);
  const [rotation, setRotation] = useState<number>(0);
  const [pointerBounce, setPointerBounce] = useState<boolean>(false);
  const prevSliceRef = useRef<number>(-1);
  const animFrameRef = useRef<number | null>(null);

  const numSlices = prizes.length;
  const sliceAngle = 360 / numSlices;

  // Handle spin execution when targetPrize changes and isSpinning is true
  useEffect(() => {
    if (isSpinning && targetPrize) {
      sound.playWhoosh();
      const targetIndex = prizes.findIndex((p) => p.id === targetPrize.id);
      const safeIndex = targetIndex >= 0 ? targetIndex : 0;

      // Slice middle angle:
      // Slice 0 starts at angle 0. Pointer is at TOP (270 deg or 90 deg depending on coordinate system).
      // Let's standardise: Slice 0 starts at -90 deg (12 o'clock).
      // So slice i center is at: -90 + (i * sliceAngle) + (sliceAngle / 2)
      // To bring slice i to top, wheel must rotate so that slice center meets top.
      const baseFullSpins = 5 + Math.floor(Math.random() * 2); // 5 to 6 full turns
      const prizeCenterAngle = safeIndex * sliceAngle + sliceAngle / 2;
      
      // Add slight jitter inside the slice (+- 30% of slice width) so it doesn't always land at the dead center
      const jitter = (Math.random() - 0.5) * (sliceAngle * 0.5);

      // We want: (rotation + targetDelta) % 360 + prizeCenterAngle === 360 (or aligned to top)
      // Top is at angle 0 in rotation transform if slice 0 center is at 0 degrees at top.
      const currentMod = rotation % 360;
      const destinationAngle = 360 * baseFullSpins - prizeCenterAngle + jitter;
      const finalRotation = rotation + (360 - currentMod) + destinationAngle;

      const durationMs = 5200;
      const startTime = performance.now();
      const startRotation = rotation;

      // Custom cubic ease out
      const easeOut = (t: number) => {
        // Cubic bezier approximation
        return 1 - Math.pow(1 - t, 4);
      };

      const animate = (currentTime: number) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / durationMs, 1);
        const eased = easeOut(progress);
        const currentRot = startRotation + (finalRotation - startRotation) * eased;

        setRotation(currentRot);

        // Sound tick check: calculate which slice is passing top
        // Normalizing angle relative to top
        const normalizedAngle = (360 - (currentRot % 360) + 360) % 360;
        const currentSliceIndex = Math.floor(normalizedAngle / sliceAngle);

        if (currentSliceIndex !== prevSliceRef.current) {
          prevSliceRef.current = currentSliceIndex;
          sound.playTick(0.9 + Math.random() * 0.3);
          setPointerBounce(true);
          setTimeout(() => setPointerBounce(false), 80);
        }

        if (progress < 1) {
          animFrameRef.current = requestAnimationFrame(animate);
        } else {
          setRotation(finalRotation);
          onSpinEnd(targetPrize);
        }
      };

      animFrameRef.current = requestAnimationFrame(animate);

      return () => {
        if (animFrameRef.current) {
          cancelAnimationFrame(animFrameRef.current);
        }
      };
    }
  }, [isSpinning, targetPrize]);

  // Polar to Cartesian coordinate helper
  const polarToCartesian = (
    centerX: number,
    centerY: number,
    radius: number,
    angleInDegrees: number
  ) => {
    // Offset by -90 so 0 degrees is at 12 o'clock (top)
    const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
    return {
      x: centerX + radius * Math.cos(angleInRadians),
      y: centerY + radius * Math.sin(angleInRadians),
    };
  };

  const createSlicePath = (
    cx: number,
    cy: number,
    radius: number,
    startAngle: number,
    endAngle: number
  ) => {
    const start = polarToCartesian(cx, cy, radius, endAngle);
    const end = polarToCartesian(cx, cy, radius, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
    return [
      `M ${cx} ${cy}`,
      `L ${start.x} ${start.y}`,
      `A ${radius} ${radius} 0 ${largeArcFlag} 0 ${end.x} ${end.y}`,
      'Z',
    ].join(' ');
  };

  const size = 340;
  const center = size / 2;
  const radius = center - 20;

  return (
    <div className="relative w-full max-w-[340px] aspect-square mx-auto flex items-center justify-center">
      {/* Outer Glow Ring */}
      <div className="absolute inset-2 rounded-full bg-gradient-to-r from-amber-400 via-purple-600 to-amber-500 blur-md opacity-40 animate-pulse pointer-events-none" />

      {/* Outer Metallic & Gold Rim */}
      <div className="absolute inset-0 rounded-full border-4 border-amber-400 bg-gradient-to-b from-amber-300 via-amber-600 to-amber-900 shadow-[0_10px_25px_rgba(0,0,0,0.8)] pointer-events-none p-1">
        <div className="w-full h-full rounded-full border-2 border-amber-200/60 bg-slate-950 flex items-center justify-center relative overflow-hidden">
          {/* Decorative Rim Rivets/Lights */}
          {Array.from({ length: 24 }).map((_, i) => {
            const angle = (i * 360) / 24;
            const pos = polarToCartesian(165, 165, 160, angle);
            return (
              <div
                key={i}
                className="absolute w-2 h-2 rounded-full shadow-sm"
                style={{
                  left: `${pos.x - 4}px`,
                  top: `${pos.y - 4}px`,
                  backgroundColor: i % 2 === 0 ? '#fef08a' : '#f59e0b',
                  boxShadow: i % 2 === 0 ? '0 0 6px #fde047' : 'none',
                }}
              />
            );
          })}
        </div>
      </div>

      {/* Pointer at the Top (12 o'clock) */}
      <div
        className={`absolute -top-3 z-30 transition-transform duration-75 origin-top filter drop-shadow-[0_4px_6px_rgba(0,0,0,0.8)] ${
          pointerBounce ? '-rotate-12 scale-110' : 'rotate-0'
        }`}
      >
        <svg width="42" height="48" viewBox="0 0 42 48" fill="none">
          <defs>
            <linearGradient id="pointerGold" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#fffbeb" />
              <stop offset="35%" stopColor="#fbbf24" />
              <stop offset="100%" stopColor="#b45309" />
            </linearGradient>
            <linearGradient id="pointerGem" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#ec4899" />
              <stop offset="100%" stopColor="#9333ea" />
            </linearGradient>
          </defs>
          {/* Pointer needle */}
          <polygon
            points="21,46 5,8 37,8"
            fill="url(#pointerGold)"
            stroke="#78350f"
            strokeWidth="2"
          />
          <polygon points="21,41 10,10 32,10" fill="#fef08a" />
          {/* Top gem rivet */}
          <circle cx="21" cy="12" r="7" fill="url(#pointerGem)" stroke="#ffffff" strokeWidth="1.5" />
        </svg>
      </div>

      {/* Spinning SVG Wheel */}
      <svg
        ref={wheelRef}
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="relative z-10 transition-none"
        style={{
          transform: `rotate(${rotation}deg)`,
          transformOrigin: '50% 50%',
        }}
      >
        <defs>
          <filter id="sliceShadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="0" stdDeviation="1" floodColor="#000000" floodOpacity="0.4" />
          </filter>
        </defs>

        {/* Wheel Slices */}
        {prizes.map((prize, idx) => {
          const startAngle = idx * sliceAngle;
          const endAngle = startAngle + sliceAngle;
          const path = createSlicePath(center, center, radius, startAngle, endAngle);

          // Position text along the slice center ray
          const textAngle = startAngle + sliceAngle / 2;
          // Position text at ~65% radius
          const textPos = polarToCartesian(center, center, radius * 0.62, textAngle);

          return (
            <g key={prize.id}>
              {/* Slice Background */}
              <path
                d={path}
                fill={prize.color}
                stroke="#1e293b"
                strokeWidth="2"
                filter="url(#sliceShadow)"
              />

              {/* Text / Label */}
              <g
                transform={`translate(${textPos.x}, ${textPos.y}) rotate(${textAngle + 90})`}
                className="select-none pointer-events-none"
              >
                <text
                  x="0"
                  y="0"
                  fill={prize.textColor || '#ffffff'}
                  textAnchor="middle"
                  dominantBaseline="central"
                  className="font-clash text-[11px] font-bold tracking-tight"
                  style={{
                    filter: 'drop-shadow(0px 1px 2px rgba(0,0,0,0.8))',
                  }}
                >
                  {prize.name.length > 14
                    ? `${prize.name.substring(0, 13)}…`
                    : prize.name}
                </text>
              </g>

              {/* Outer Edge Peg (Golden pin) */}
              {(() => {
                const pegPos = polarToCartesian(center, center, radius - 4, startAngle);
                return (
                  <circle
                    cx={pegPos.x}
                    cy={pegPos.y}
                    r="3.5"
                    fill="#fef08a"
                    stroke="#854d0e"
                    strokeWidth="1.5"
                  />
                );
              })()}
            </g>
          );
        })}

        {/* Center Hub: Custom Logo or Clash Royale Golden Emblem */}
        {centerLogoUrl ? (
          <g>
            <defs>
              <clipPath id="centerHubLogoClip">
                <circle cx={center} cy={center} r="28" />
              </clipPath>
            </defs>
            {/* Outer golden rim */}
            <circle cx={center} cy={center} r="33" fill="#78350f" stroke="#fef08a" strokeWidth="3" />
            <circle cx={center} cy={center} r="29" fill="#0f172a" stroke="#f59e0b" strokeWidth="2" />
            {/* Custom Logo Image */}
            <image
              href={centerLogoUrl}
              x={center - 28}
              y={center - 28}
              width="56"
              height="56"
              clipPath="url(#centerHubLogoClip)"
              preserveAspectRatio="xMidYMid slice"
            />
            {/* Shiny overlay rim */}
            <circle cx={center} cy={center} r="28" fill="none" stroke="#fef08a" strokeWidth="1.5" opacity="0.8" />
          </g>
        ) : (
          <g>
            <circle cx={center} cy={center} r="32" fill="#78350f" stroke="#fef08a" strokeWidth="3" />
            <circle cx={center} cy={center} r="26" fill="#1e1b4b" stroke="#f59e0b" strokeWidth="2" />
            <circle cx={center} cy={center} r="18" fill="#9333ea" />
            {/* Star in center */}
            <polygon
              points={`${center},${center - 11} ${center + 3},${center - 3} ${center + 11},${center} ${center + 3},${center + 3} ${center},${center + 11} ${center - 3},${center + 3} ${center - 11},${center} ${center - 3},${center - 3}`}
              fill="#fef08a"
            />
          </g>
        )}
      </svg>
    </div>
  );
};
