import React, { useState } from 'react';
import { ShieldCheck, X, AlertCircle } from 'lucide-react';
import { sound } from '../utils/sound';

interface AdminLoginModalProps {
  currentPin: string;
  onSuccess: () => void;
  onClose: () => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  currentPin,
  onSuccess,
  onClose,
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.trim() === '108110' || pin.trim() === currentPin.trim()) {
      sound.playClick();
      setError(false);
      onSuccess();
    } else {
      sound.playFailSound();
      setError(true);
      setPin('');
    }
  };

  const handleKeyClick = (digit: string) => {
    sound.playTick(1.2);
    if (pin.length < 8) {
      setPin((prev) => prev + digit);
    }
  };

  const handleBackspace = () => {
    sound.playTick(0.8);
    setPin((prev) => prev.slice(0, -1));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xs bg-slate-900 border-2 border-amber-500/60 rounded-3xl p-5 shadow-2xl relative text-center">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-1.5 text-slate-400 hover:text-white rounded-full bg-slate-800/80 transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-3 text-amber-400">
          <ShieldCheck className="w-6 h-6" />
        </div>

        <h3 className="font-clash text-xl text-white">Acceso Administrador</h3>
        <p className="text-xs text-slate-400 mt-1 mb-4">
          Ingresa el PIN de seguridad para gestionar premios y números
        </p>

        {/* PIN input display with 6 digits */}
        <form onSubmit={handleSubmit} className="mb-4">
          <div className="flex justify-center items-center gap-1.5 mb-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className={`w-9 h-11 rounded-xl border-2 flex items-center justify-center text-xl font-bold font-mono transition-all ${
                  pin.length > i
                    ? 'border-amber-400 bg-amber-500/15 text-amber-300'
                    : 'border-slate-700 bg-slate-950 text-slate-600'
                }`}
              >
                {pin.length > i ? '•' : ''}
              </div>
            ))}
          </div>

          {error && (
            <p className="text-xs text-rose-400 flex items-center justify-center gap-1 mt-2">
              <AlertCircle className="w-3.5 h-3.5" /> PIN incorrecto. Intenta de nuevo.
            </p>
          )}

          {/* Quick PIN Keypad for touch/mobile */}
          <div className="grid grid-cols-3 gap-2 mt-4">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map(
              (btn) => (
                <button
                  type="button"
                  key={btn}
                  onClick={() => {
                    if (btn === 'C') {
                      sound.playTick(0.7);
                      setPin('');
                    } else if (btn === '⌫') {
                      handleBackspace();
                    } else {
                      handleKeyClick(btn);
                    }
                  }}
                  className="h-11 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white font-clash text-lg border border-slate-700 active:scale-95 transition"
                >
                  {btn}
                </button>
              )
            )}
          </div>

          <button
            type="submit"
            disabled={pin.length < 4}
            className={`w-full mt-4 py-2.5 rounded-xl font-clash text-sm transition shadow-lg ${
              pin.length >= 4
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 hover:from-amber-400 hover:to-yellow-300 cursor-pointer'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
            }`}
          >
            INGRESAR AL PANEL
          </button>
        </form>
      </div>
    </div>
  );
};
