import React, { useState, useEffect, useMemo } from 'react';
import {
  Sparkles,
  Phone,
  AlertTriangle,
  Gift,
  HelpCircle,
  Trophy,
  ChevronDown,
  Info,
  RotateCcw,
} from 'lucide-react';
import { Prize, SpinRecord, AdminSettings } from './types/game';
import { storage, normalizePhone, generateClaimCode } from './utils/storage';
import { sound } from './utils/sound';
import { Header } from './components/Header';
import { Wheel } from './components/Wheel';
import { ChestModal } from './components/ChestModal';
import { AdminPanel } from './components/AdminPanel';
import { AdminLoginModal } from './components/AdminLoginModal';

const COUNTRY_CODES = [
  { code: '+503', flag: '🇸🇻', country: 'El Salvador' },
  { code: '+52', flag: '🇲🇽', country: 'México' },
  { code: '+1', flag: '🇺🇸', country: 'USA/Canadá' },
  { code: '+34', flag: '🇪🇸', country: 'España' },
  { code: '+57', flag: '🇨🇴', country: 'Colombia' },
  { code: '+54', flag: '🇦🇷', country: 'Argentina' },
  { code: '+56', flag: '🇨🇱', country: 'Chile' },
  { code: '+51', flag: '🇵🇪', country: 'Perú' },
  { code: '+502', flag: '🇬🇹', country: 'Guatemala' },
  { code: '+504', flag: '🇭🇳', country: 'Honduras' },
  { code: '+505', flag: '🇳🇮', country: 'Nicaragua' },
  { code: '+506', flag: '🇨🇷', country: 'Costa Rica' },
  { code: '+507', flag: '🇵🇦', country: 'Panamá' },
  { code: '+593', flag: '🇪🇨', country: 'Ecuador' },
  { code: '+58', flag: '🇻🇪', country: 'Venezuela' },
  { code: '+591', flag: '🇧🇴', country: 'Bolivia' },
  { code: '+595', flag: '🇵🇾', country: 'Paraguay' },
  { code: '+598', flag: '🇺🇾', country: 'Uruguay' },
  { code: '+1809', flag: '🇩🇴', country: 'Rep. Dominicana' },
];

export default function App() {
  // App state
  const [prizes, setPrizes] = useState<Prize[]>([]);
  const [history, setHistory] = useState<SpinRecord[]>([]);
  const [settings, setSettings] = useState<AdminSettings>(storage.getSettings());
  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(sound.enabled);

  // Phone input state - defaulted to El Salvador (+503)
  const [countryCode, setCountryCode] = useState<string>('+503');
  const [phoneNumber, setPhoneNumber] = useState<string>('');

  // Spinning state
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [targetPrize, setTargetPrize] = useState<Prize | null>(null);

  // Modals
  const [activeChestModal, setActiveChestModal] = useState<{
    prize: Prize;
    record: SpinRecord;
  } | null>(null);
  const [showAdminLogin, setShowAdminLogin] = useState<boolean>(false);
  const [showAdminPanel, setShowAdminPanel] = useState<boolean>(false);
  const [showRulesModal, setShowRulesModal] = useState<boolean>(false);

  // Load initial state and synchronize with server for shared link support
  useEffect(() => {
    setPrizes(storage.getPrizes());
    setHistory(storage.getHistory());
    setSettings(storage.getSettings());

    storage.fetchServerData().then((serverData) => {
      if (serverData) {
        if (serverData.prizes && serverData.prizes.length >= 2) setPrizes(serverData.prizes);
        if (serverData.history) setHistory(serverData.history);
        if (serverData.settings) setSettings((prev) => ({ ...prev, ...serverData.settings }));
      }
    });
  }, []);

  // Extract exactly up to 8 numeric digits
  const rawPhoneDigits = useMemo(() => {
    return phoneNumber.replace(/\D/g, '').slice(0, 8);
  }, [phoneNumber]);

  // Compute full cleaned phone number
  const fullPhoneNumber = useMemo(() => {
    if (rawPhoneDigits.length !== 8) return '';
    const codeClean = normalizePhone(countryCode);
    return `${codeClean}${rawPhoneDigits}`;
  }, [countryCode, rawPhoneDigits]);

  // Check if current phone has already played
  const playedRecord = useMemo(() => {
    if (!fullPhoneNumber) return null;
    return history.find((r) => normalizePhone(r.phoneNumber) === fullPhoneNumber) || null;
  }, [fullPhoneNumber, history]);

  // Weighted random selection
  const selectTargetPrize = (): Prize => {
    const totalWeight = prizes.reduce((acc, p) => acc + (p.weight || 1), 0);
    let rand = Math.random() * totalWeight;

    for (const prize of prizes) {
      const weight = prize.weight || 1;
      if (rand < weight) {
        return prize;
      }
      rand -= weight;
    }
    return prizes[0];
  };

  // Handle spin button click
  const handleSpinClick = () => {
    if (isSpinning) return;
    if (rawPhoneDigits.length !== 8) {
      alert('Por favor ingresa un número de teléfono de exactamente 8 dígitos.');
      return;
    }
    if (playedRecord) {
      alert('Este número de teléfono ya ha participado. Solo se permite 1 giro por número.');
      return;
    }

    sound.playClick();
    const chosenPrize = selectTargetPrize();
    setTargetPrize(chosenPrize);
    setIsSpinning(true);
  };

  // Callback when wheel finishes animation
  const handleSpinEnd = (wonPrize: Prize) => {
    setIsSpinning(false);

    // Create record
    const claimCode = generateClaimCode(wonPrize.couponPrefix || 'ROYALE');
    const newRecord: SpinRecord = {
      id: `spin-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      phoneNumber: fullPhoneNumber,
      timestamp: Date.now(),
      prizeId: wonPrize.id,
      prizeName: wonPrize.name,
      isPrize: wonPrize.isPrize,
      chestType: wonPrize.chestType,
      claimCode,
      claimed: false,
    };

    // Commit to storage & local state
    storage.recordSpin(newRecord);
    setHistory(storage.getHistory());

    // Open chest modal
    setActiveChestModal({
      prize: wonPrize,
      record: newRecord,
    });
  };

  // Admin callbacks
  const handleUpdatePrizes = (newPrizes: Prize[]) => {
    setPrizes(newPrizes);
    storage.savePrizes(newPrizes);
  };

  const handleUpdateSettings = (newSettings: AdminSettings) => {
    setSettings(newSettings);
    storage.saveSettings(newSettings);
  };

  const handleDeleteRecord = (id: string) => {
    storage.deleteRecord(id);
    setHistory(storage.getHistory());
  };

  const handleToggleClaimed = (id: string) => {
    storage.toggleClaimed(id);
    setHistory(storage.getHistory());
  };

  const handleClearHistory = () => {
    storage.clearAllHistory();
    setHistory([]);
  };

  const handleTestChest = (prize: Prize) => {
    const testRecord: SpinRecord = {
      id: 'test-record',
      phoneNumber: '520000000000',
      timestamp: Date.now(),
      prizeId: prize.id,
      prizeName: prize.name,
      isPrize: prize.isPrize,
      chestType: prize.chestType,
      claimCode: 'ROYALE-TEST99',
      claimed: false,
    };
    setActiveChestModal({
      prize,
      record: testRecord,
    });
  };

  const customFontFamily = settings.themeConfig?.fontFamily || "'Luckiest Guy', cursive, sans-serif";
  const mainTitleColor = settings.themeConfig?.titleColor || '#ffffff';
  const subtitleColor = settings.themeConfig?.subtitleColor || '#cbd5e1';
  const mainTitle = settings.themeConfig?.mainTitle || '¡GIRA Y GANA!';
  const subtitle = settings.themeConfig?.subtitle || 'Abre el cofre legendario estilo Clash Royale y descubre tu premio.';
  const bannerText = settings.themeConfig?.bannerText || '1 Giro Gratis por Teléfono';
  const spinButtonText = settings.themeConfig?.spinButtonText || '¡GIRAR RULETA AHORA!';

  return (
    <div
      style={{ fontFamily: customFontFamily }}
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-slate-950 relative overflow-x-hidden"
    >
      {/* Background radial glow */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-purple-900/25 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-[400px] h-[300px] bg-amber-600/15 rounded-full blur-3xl" />
      </div>

      {/* Main Top Header */}
      <Header
        storeName={settings.storeName}
        headerLogoUrl={settings.headerLogoUrl}
        isSoundEnabled={isSoundEnabled}
        onToggleSound={() => setIsSoundEnabled(sound.toggleSound())}
        onOpenAdmin={() => setShowAdminLogin(true)}
      />

      {/* Main Game Arena (Mobile optimized container) */}
      <main className="w-full max-w-md mx-auto px-4 py-2 flex flex-col items-center flex-1 justify-center z-10">
        {/* Title Header */}
        <div className="w-full text-center mb-2">
          <h2
            style={{ color: mainTitleColor }}
            className="text-2xl xs:text-3xl font-clash text-stroke-gold tracking-wide drop-shadow-md"
          >
            {mainTitle}
          </h2>
          <p
            style={{ color: subtitleColor }}
            className="text-xs max-w-xs mx-auto font-sans font-medium mt-1"
          >
            {subtitle}
          </p>
        </div>

        {/* Roulette Wheel */}
        <div className="w-full my-1 flex justify-center">
          <Wheel
            prizes={prizes}
            isSpinning={isSpinning}
            targetPrize={targetPrize}
            centerLogoUrl={settings.wheelCenterLogoUrl}
            onSpinEnd={handleSpinEnd}
          />
        </div>

        {/* Phone Input & Action Section */}
        <div className="w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-2xl backdrop-blur-md mt-2">
          {/* Label */}
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5 font-clash">
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              TU NÚMERO DE TELÉFONO
            </label>
            <button
              onClick={() => setShowRulesModal(true)}
              className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold"
            >
              <HelpCircle className="w-3 h-3" />
              ¿Cómo funciona?
            </button>
          </div>

          {/* Phone Form Input */}
          <div className="flex gap-2">
            {/* Country Selector */}
            <div className="relative shrink-0">
              <select
                value={countryCode}
                disabled={isSpinning}
                onChange={(e) => setCountryCode(e.target.value)}
                className="h-12 bg-slate-950 border border-slate-700 rounded-2xl px-2.5 text-xs font-bold text-white appearance-none pr-7 focus:outline-none focus:border-amber-400 cursor-pointer disabled:opacity-50"
              >
                {COUNTRY_CODES.map((c) => (
                  <option key={c.code} value={c.code} className="bg-slate-900 text-white">
                    {c.flag} {c.code}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-4 pointer-events-none" />
            </div>

            {/* Tel Input */}
            <div className="relative flex-1">
              <input
                type="tel"
                disabled={isSpinning}
                maxLength={8}
                placeholder="Ej: 71234567"
                value={phoneNumber}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 8);
                  setPhoneNumber(val);
                }}
                className={`w-full h-12 bg-slate-950 border rounded-2xl px-3.5 text-base font-mono font-bold text-white placeholder-slate-500 focus:outline-none transition-all ${
                  playedRecord
                    ? 'border-rose-500/80 ring-2 ring-rose-500/30'
                    : rawPhoneDigits.length === 8
                    ? 'border-emerald-500/80 ring-2 ring-emerald-500/30 text-emerald-300'
                    : 'border-slate-700 focus:border-amber-400'
                }`}
              />
              {rawPhoneDigits.length > 0 && !playedRecord && (
                <span className="absolute right-3 top-3.5 text-[11px] font-mono font-bold text-slate-400 pointer-events-none">
                  {rawPhoneDigits.length}/8
                </span>
              )}
            </div>
          </div>

          {/* Status Message Display */}
          <div className="mt-2.5">
            {playedRecord ? (
              /* Already played alert */
              <div className="bg-rose-950/60 border border-rose-500/50 rounded-2xl p-3 animate-in fade-in">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-xs font-bold text-rose-200 leading-tight">
                      Este número ya giró la ruleta
                    </p>
                    <p className="text-[11px] text-rose-300/90 mt-0.5">
                      Participó el {new Date(playedRecord.timestamp).toLocaleDateString('es-ES')} con resultado:{' '}
                      <span className="font-bold text-amber-300">"{playedRecord.prizeName}"</span>
                    </p>

                    {/* View result button */}
                    <button
                      onClick={() => {
                        sound.playClick();
                        const p = prizes.find((x) => x.id === playedRecord.prizeId) || {
                          id: playedRecord.prizeId,
                          name: playedRecord.prizeName,
                          isPrize: playedRecord.isPrize,
                          chestType: playedRecord.chestType,
                          color: '#3b82f6',
                          textColor: '#ffffff',
                          imageUrl: settings.noPrizeConfig.imageUrl,
                          weight: 1,
                        };
                        setActiveChestModal({
                          prize: p,
                          record: playedRecord,
                        });
                      }}
                      className="mt-2 text-xs font-clash text-white bg-rose-900/80 hover:bg-rose-800 px-3 py-1.5 rounded-xl border border-rose-600 flex items-center gap-1.5 transition"
                    >
                      <Trophy className="w-3.5 h-3.5 text-amber-400" />
                      Ver mi premio obtenido
                    </button>
                  </div>
                </div>
              </div>
            ) : rawPhoneDigits.length === 8 ? (
              <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold px-1">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>¡Número de 8 dígitos listo ({countryCode} {rawPhoneDigits})! Puedes girar la ruleta.</span>
              </div>
            ) : rawPhoneDigits.length > 0 ? (
              <div className="flex items-center justify-between text-xs text-amber-300/90 px-1 font-mono">
                <span>Faltan {8 - rawPhoneDigits.length} dígitos para completar tu número (solo 8 dígitos)</span>
                <span className="font-bold text-amber-400">{rawPhoneDigits.length}/8</span>
              </div>
            ) : (
              <p className="text-[11px] text-slate-400 px-1 text-center">
                Ingresa tu número de <span className="text-amber-400 font-semibold">exactamente 8 dígitos</span> (1 intento por número).
              </p>
            )}
          </div>

          {/* Big Spin Action Button */}
          <button
            onClick={handleSpinClick}
            disabled={isSpinning || !!playedRecord || rawPhoneDigits.length !== 8}
            className={`w-full mt-3 h-14 rounded-2xl font-clash text-lg tracking-wider transition-all duration-200 flex items-center justify-center gap-2 select-none shadow-xl ${
              isSpinning
                ? 'bg-amber-600/70 text-slate-900 cursor-wait animate-pulse'
                : playedRecord
                ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                : rawPhoneDigits.length === 8
                ? 'bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-500 hover:from-yellow-200 hover:to-amber-400 text-slate-950 border-2 border-yellow-200 shadow-amber-500/40 ring-4 ring-amber-500/20 active:scale-98 cursor-pointer'
                : 'bg-slate-850 text-slate-500 border border-slate-800 cursor-not-allowed'
            }`}
          >
            {isSpinning ? (
              <>
                <RotateCcw className="w-5 h-5 animate-spin" />
                ¡GIRANDO LA SUERTE...!
              </>
            ) : playedRecord ? (
              'NÚMERO YA PARTICIPÓ'
            ) : rawPhoneDigits.length === 8 ? (
              <>
                <Gift className="w-5 h-5 text-slate-950" />
                {spinButtonText}
              </>
            ) : (
              `INGRESA 8 DÍGITOS (${rawPhoneDigits.length}/8)`
            )}
          </button>
        </div>
      </main>

      {/* Footer Info */}
      <footer className="w-full max-w-md mx-auto py-3 px-4 text-center text-[11px] text-slate-400 shrink-0 z-10">
        <p>
          © {new Date().getFullYear()} {settings.storeName} • 1 participación por número de celular
        </p>
      </footer>

      {/* ================= MODALS ================= */}

      {/* Clash Royale Chest Reveal Modal with Epic Fireworks */}
      {activeChestModal && (
        <ChestModal
          prize={activeChestModal.prize}
          spinRecord={activeChestModal.record}
          noPrizeConfig={settings.noPrizeConfig}
          storeName={settings.storeName}
          claimInstructions={settings.claimInstructions}
          themeConfig={settings.themeConfig}
          onClose={() => setActiveChestModal(null)}
        />
      )}

      {/* Admin Login Modal (PIN entry) */}
      {showAdminLogin && (
        <AdminLoginModal
          currentPin={settings.adminPin}
          onSuccess={() => {
            setShowAdminLogin(false);
            setShowAdminPanel(true);
          }}
          onClose={() => setShowAdminLogin(false)}
        />
      )}

      {/* Full Admin Panel */}
      {showAdminPanel && (
        <AdminPanel
          prizes={prizes}
          history={history}
          settings={settings}
          onUpdatePrizes={handleUpdatePrizes}
          onUpdateSettings={handleUpdateSettings}
          onDeleteRecord={handleDeleteRecord}
          onToggleClaimed={handleToggleClaimed}
          onClearHistory={handleClearHistory}
          onTestChest={handleTestChest}
          onClose={() => setShowAdminPanel(false)}
        />
      )}

      {/* Rules / How it Works Modal */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-5 max-w-xs w-full shadow-2xl text-center">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3">
              <Info className="w-5 h-5" />
            </div>
            <h3 className="font-clash text-lg text-white mb-2">¿Cómo Funciona?</h3>
            <ul className="text-xs text-slate-300 text-left space-y-2 mb-4 leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">1.</span>
                Ingresa tu número de teléfono móvil (exactamente 8 dígitos).
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">2.</span>
                Toca en <strong className="text-white">Girar Ruleta</strong>. Solo tienes 1 intento disponible.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">3.</span>
                ¡Abre tu cofre tocando la pantalla! Si ganas, recibirás un Cofre Legendario con tu premio.
              </li>
            </ul>
            <button
              onClick={() => {
                sound.playClick();
                setShowRulesModal(false);
              }}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-clash text-xs transition"
            >
              ¡ENTENDIDO!
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
